<?php

$lang = array();
$lang['pusher_does_not_exist']= "Pusher does't exist";
$lang['pushers_exist']= "Thes pusher credencials already exist";


return $lang;




