<?php

$lang = array();
$lang['group']['create']= "Group:%%group_name%% has been created successfully";
$lang['group']['update']= "Group:%%group_name%% has been updates successfully";
$lang['group']['deleted']= "Group:%%group_name%% has been deleted successfully";
$lang['pusher']['create']= "Pusher  has been created successfully";
$lang['pusher']['update']= "Pusher has been updates successfully";
$lang['pusher']['deleted']= "Pusher  has been deleted successfully";
$lang['whatsapp_sender_numbers']['update']= "whatsapp Sending Numbers Has Been Updates Successfully";
$lang['whatsapp_sender_numbers']['create']= "whatsapp Sending Numbers Has Been Added Successfully";
$lang['whatsapp_sender_numbers']['deleted']= "whatsapp Sending Numbers Has Been Deleted successfully";

$lang['whatsapp_template']['update']= "whatsapp Template Has Been Updates Successfully";
$lang['whatsapp_template']['create']= "whatsapp Template Has Been Added Successfully";
$lang['whatsapp_template']['deleted']= "whatsapp Template Has Been Deleted successfully";

return $lang;




