<?php

$lang = array();
$lang['error']= "Error: Something went wrong! try again.";
$lang['edit']= "Edit";
$lang['delete']= "Delete";
$lang['actions']= "Actions";
$lang['action']= "Action";
$lang['save_changes']= "Save changes";
$lang['cancel']= "Cancel";
$lang['plz_wait']= "Please wait... ";
$lang['permission_error'] ='Error in file uploading. Create Folder "users_profiles in storage" with 777 permissions';
$lang['extension_error'] ="This file extension is not allowed, allowed extensions 'jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'PNG', 'gif', 'GIF', 'bmp', 'BMP','webp'";
$lang['invalid_file'] ='Invalid File';
$lang['system_error'] ='oops there is something wrong with the system. Contact to the administrator.';


return $lang;




