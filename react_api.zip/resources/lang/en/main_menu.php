<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
$lang = array();
$lang['users']= "Users";
$lang['sub_menu_list']['view_list']= "View Lists";
$lang['sub_menu_add_list']= "Add Lists";
$lang['setup']= "Setup";
$lang['sub_menu_setup']['package']= "Package";
$lang['package_sub_menu_setup']['add_package']= "Add Package";
$lang['package_sub_menu_setup']['view_package']= "View Package";
$lang['statistics']= "Statictics";
$lang['sub_menu_statistics']['broadcast_stats']= "Broadcast stats";
$lang['sub_menu_statistics']['trigger_stats']= "Trigger Stats";
$lang['sub_menu_setup']['user_management']= "User managment";
$lang['sub_menu_setup']['roles']= "Roles";
$lang['sub_menu_setup']['add_role']= "Add Role";
$lang['sub_menu_setup']['view_roles']= "View Roles";
$lang['sub_menu_setup']['notification_center']= "Notification Center";
$lang['sub_menu_setup']['view_admin_notification']= "Admin Notifications";
$lang['sub_menu_setup']['view_client_notification']= "Client Notifications";
$lang['sub_menu_setup']['view_notification_templates']= "Notification Templates";
$lang['sub_menu_setup']['view_users']= "View Users";
$lang['sub_menu_setup']['add_user']= "Add Users";


return $lang;




