<?php

$lang = array();
$lang['group']['create']= "Group created successfully";
$lang['group']['update']= "Group updated successfully";
$lang['activity_logs_admin']['group']['update']= "Group created successfully";
$lang['activity_logs_admin']['group']['insert']= "%%client_link%% added a group %%group_link%%";
$lang['pusher']['create']= "Pusher credencial has been created successfully";
$lang['pusher']['update']= "Pusher credencial has been updated successfully";

$lang['whatsapp_sender_numbers']['update']= "WhatsApp Sending Number has been updated successfully";
$lang['admin']['whatsapp_sender_numbers']['update']= "WhatsApp Sending Number has been updated successfully";
$lang['admin']['whatsapp_sender_numbers']['insert']= "%%mobile_no_link%% added has WhatsApp Sending Number";


$lang['whatsapp_sender_numbers']['update']= "WhatsApp Sending Number Has Been Updated Successfully";
$lang['whatsapp_sender_numbers']['insert']= "WhatsApp Sending Number Has Been Updated Successfully";

$lang['group']['admin']['imported']= "Contacts Has Been Importeds Successfully";


return $lang;




