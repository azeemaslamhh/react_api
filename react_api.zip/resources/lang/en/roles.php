<?php

$lang = array();
$lang['add_role']['title']= "Create Role";
$lang['add_role']['description']= "Create Role Description";
$lang['edit_package']['title']= "Edit Role";
$lang['edit_package']['description']= "Edit Role Description";

$lang['add_role']['role_name']= "Role";
$lang['add_role']['role_name_help'] = "Role Help";

$lang['add_role']['save_success']['message']= "The Role Has Been Successfully Created";
$lang['add_role']['update_success']['message']= "The Role Has Been Successfully Updated";
$lang['add_role']['validation_message']['role_name']= "Enter The Role";


$lang['view_role']['title']= "View roles";
$lang['view_role']['description']= "View Roles Description";
$lang['view_role']['role']= "Role";
$lang['view_role']['actions']= "Actions";


$lang['view_role']['cannot_delete_role_message']= "This Role Cannot Be Deleted Becasue This Role is Linked With Users";
$lang['view_role']['delete_missage']= "Role Has Been Deleted Successfully";
return $lang;




