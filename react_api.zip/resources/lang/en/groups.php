<?php

$lang = array();
$lang['group_does_not_exist']= "Group does't exist";
$lang['group_name_exist']= "Group-'%%group_name%%' already exist";
$lang['add_package']['name']= "Package Name";

return $lang;




