<?php

$lang = array();
$lang['invalid_status']= "Invalid Status";
$lang['number_not_exist']= "Number ID does't exist";
$lang['mobile_no_not_exist']= "Mobile No:%%mobile_no%%  Already Exist";
$lang['whatsapp_credencial_id_not_exist']= "Whatsapp credencial id does't exist";
$lang['whatsapp_template_id_not_exist']= "Whatsapp template id does't exist";
$lang['template_name_already_exist']= "template name:%%template_name%% already exist";


return $lang;




