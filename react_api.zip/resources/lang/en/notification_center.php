<?php

$lang = array();
$lang['view_admin_notification']['title']= "View Admin Notifications";
$lang['view_admin_notification']['description']= "View Admin Notifications description";
$lang['view_admin_notification']['modules']= "Modules";
$lang['view_admin_notification']['email']= "Email";
$lang['view_admin_notification']['whatsapp']= "WhatsApp";
$lang['view_admin_notification']['roles']= "Roles";
$lang['view_admin_notification']['template']= "Template";
$lang['view_client_notification']['title']= "View Client Notifications";
$lang['view_client_notification']['description']= "View Client Notifications description";

$lang['add_admin_notification']['title']= "Admin Notification Template";
$lang['add_admin_notification']['description']= "Setup content for WhatsApp and email notifcation for specific module.";
$lang['edit_admin_notification']['title']= "Admin Notification Template";
$lang['edit_admin_notification']['description']= "Setup content for WhatsApp and email notifcation for specific module.";
$lang['add_admin_notification']['title']= "Admin Notification Template";
$lang['add_admin_notification']['modules']= "Modules";
$lang['add_admin_notification']['select_module']= "Select Module";
$lang['add_admin_notification']['template_name']= "Template Name";
$lang['add_admin_notification']['subject']= "Subject";
$lang['add_admin_notification']['email_message_body']= "Email Message Body";
$lang['add_admin_notification']['whatsapp_message_body']= "WhatsApp Message Body";
$lang['add_admin_notification']['add_template']= "Add Template";
$lang['add_template']['validation_message']['module_id']= "Seelct Module";
$lang['add_template']['validation_message']['template_name']= "Enter the Module Name";
$lang['add_template']['validation_message']['subject']= "Enter The Subject";
//$lang['add_template']['validation_message']['email']= "Enter The Email Message Body ";
//$lang['add_template']['validation_message']['whatsapp']= "Enter The WhatsApp Message Body";






return $lang;




