<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cron_jobs extends Model
{
    //protected  $table = 'credit_card';
    //protected $primaryKey = 'id';
    protected $guarded = [];
    public $timestamps = false;
    
}
