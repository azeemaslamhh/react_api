<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TempImportChunkFiles extends Model {

    protected $guarded = [];    
}
