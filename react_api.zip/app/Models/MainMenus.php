<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MainMenus extends Model
{
     protected $guarded = [];
     protected  $table = 'main_menus';
     protected $primaryKey = 'id';
}
