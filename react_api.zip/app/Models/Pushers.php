<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pushers extends Model {
    protected $guarded = [];   
}
