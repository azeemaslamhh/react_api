<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Activity_logs extends Model
{
    protected  $table = 'activity_logs';
    protected $guarded = [];    
}
