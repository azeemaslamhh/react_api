<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Notification_templates extends Model {

    protected $guarded = [];

}
