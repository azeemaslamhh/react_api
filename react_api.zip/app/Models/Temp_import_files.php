<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Temp_import_files extends Model
{
     protected $guarded = [];     
}
