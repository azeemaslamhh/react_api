<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhatsappCredencials extends Model {
    protected $guarded = [];   
}
