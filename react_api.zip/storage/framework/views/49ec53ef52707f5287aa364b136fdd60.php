<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  "use strict";
  var KTSigninGeneral = (function () {
  var t, e, i;
  return {
      init: function () {
      (t = document.querySelector("#list_form")),
          (e = document.querySelector("#list_submit")),
          (i = FormValidation.formValidation(t, {
          fields: {
              select: {
              validators: { notEmpty: { message: "The list name is required" } },
              },
              name: {
              validators: { notEmpty: { message: "The name is required" } },
              },
          },
          plugins: {
              trigger: new FormValidation.plugins.Trigger(),
              bootstrap: new FormValidation.plugins.Bootstrap5({
              rowSelector: ".fv-row",
              }),
          },
          })),
          e.addEventListener("click", function (n) {
          n.preventDefault(),
              i.validate().then(function (i) {
              "Valid" == i
                  ? (e.setAttribute("data-kt-indicator", "on"),
                  (e.disabled = !0),
                  setTimeout(function () {
                      $("#list_form").submit();
                  }, 0))
                  : Swal.fire({
                      text: "Sorry, looks like there are some errors detected, please try again.",
                      icon: "error",
                      buttonsStyling: !1,
                      confirmButtonText: "Ok, got it!",
                      customClass: { confirmButton: "btn btn-primary" },
                  });
              });
          });
      },
  };
  })();
  KTUtil.onDOMContentLoaded(function () {
  KTSigninGeneral.init();
  });

</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row g-5 g-xl-10">
    <div class="col-md-8 mb-md-5">
      <div class="card">
          <div class="card-header">
            <div class="card-title m-0">
              <h3 class="fw-bolder m-0">Add Group</h3>
            </div>
          </div>
            <form id="list_form" class="form" method="" action="" enctype="multipart/form-data">
            <div class="card-body border-top p-9">
              <div class="row mb-6">
                <label class="col-lg-4 col-form-label required fw-bold fs-6">Users ID</label>
                <div class="col-lg-8">
                  <div class="fv-row mb-0 fv-plugins-icon-container">
                    <select name="Choose-Group" aria-label="Choose-Group" data-control="select2" data-placeholder="Choose Group.." class="form-select form-select-solid form-select-lg">
                      <option id="select" class="">Users ID</option>
                      <option value="1">User 1</option>
                      <option value="2">User 2</option>
                      <option value="3">User 3</option>
                      <option value="4">local User</option>
                      <option value="5">User All Fields</option>
                    </select>
                    <div class="fv-plugins-message-container invalid-feedback"></div>
                  </div>
                </div>
              </div>
              <div class="row mb-6">
                <label class="col-lg-4 col-form-label required fw-bold fs-6"><?php echo e(__('Group Name')); ?></label>
                <div class="col-lg-8">
                    <div class="row">
                        <div class="fv-row mb-0 fv-plugins-icon-container">
                          <input type="text" name="name" id="name" class="form-control bg-transparent" placeholder="Group Name">
                          <div class="fv-plugins-message-container invalid-feedback"></div>
                        </div>
                    </div>
                </div>
            </div>
              <div class="row mb-6">
                <label class="col-lg-4 col-form-label fw-bold fs-6">Additional Fields</label>
                <div class="col-lg-8">
                  <div class="scroll-y" style="display: block; padding: 20px 20px 5px; border: 1px solid rgb(205, 220, 221); border-radius: 10px; max-height: 207px; overflow: auto;">
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="2">
                        <span class="fw-bold ps-2 fs-6">Company Name </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="100">
                        <span class="fw-bold ps-2 fs-6">Local City </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="101">
                        <span class="fw-bold ps-2 fs-6">Birthdate </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="102">
                        <span class="fw-bold ps-2 fs-6">Package </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="103">
                        <span class="fw-bold ps-2 fs-6">Brand </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="104">
                        <span class="fw-bold ps-2 fs-6">Comments </span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row mb-6">
                <label class="col-lg-4 col-form-label fw-bold fs-6">Custom Fields</label>
                <div class="col-lg-8">
                  <div class="scroll-y" style="display: block; padding: 20px 20px 5px; border: 1px solid rgb(205, 220, 221); border-radius: 10px; max-height: 207px; overflow: auto;">
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="109">
                        <span class="fw-bold ps-2 fs-6">c2 </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="108">
                        <span class="fw-bold ps-2 fs-6">c1 </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="93">
                        <span class="fw-bold ps-2 fs-6">Title </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="99">
                        <span class="fw-bold ps-2 fs-6">Test Require </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="94">
                        <span class="fw-bold ps-2 fs-6">Mobile No </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="110">
                        <span class="fw-bold ps-2 fs-6">c3 </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="95">
                        <span class="fw-bold ps-2 fs-6">City </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="111">
                        <span class="fw-bold ps-2 fs-6">c4 </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="96">
                        <span class="fw-bold ps-2 fs-6">D/O/B </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="97">
                        <span class="fw-bold ps-2 fs-6">Gender </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="98">
                        <span class="fw-bold ps-2 fs-6">Message </span>
                      </label>
                    </div>
                    <div>
                      <label class="form-check form-check-inline form-check-solid me-5 mb-5 cursor-pointer">
                        <input type="checkbox" class="form-check-input cursor-pointer" name="additionalfields" value="105">
                        <span class="fw-bold ps-2 fs-6">Car Intrested </span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer d-flex justify-content-end py-6 px-9">
              <button type="submit" class="btn btn-primary" id="list_submit">Save Changes</button>
            </div>
          </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\Mumara-WhatsApp\resources\views/pages/lists/create.blade.php ENDPATH**/ ?>