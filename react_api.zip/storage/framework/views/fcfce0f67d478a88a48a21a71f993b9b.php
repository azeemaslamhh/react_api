<div class="card">
    <div class="card-header border-0 py-6">
        <div class="card-title pagetitle" style="display: block;">
            <h4 class="alert-heading"><?php echo e($title); ?></h4>
            <p><?php echo e($description); ?></p>
        </div>
    </div>
</div><?php /**PATH D:\Wamp\www\Mumara-WhatsApp\resources\views/partials/title_description.blade.php ENDPATH**/ ?>