<?php $__env->startSection('style'); ?>
<link href="/public/assets/css/toastr.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="/public/assets/js/select2.full.min.js"></script>
<script src="/public/assets/js/select2.js"></script>
<script src="/public/assets/js/jquery.validate.min.js"type="text/javascript"></script>
<script src="/public/assets/js/toastr.min.js"></script>
<script>
    $(document).ready(function () {
        $("#saveBtn").attr('disabled',false);
        $("#frmPackages").validate({
            rules: {
                pkg_name: "required",
                role_id: "required",
                price_per_message: "required",
                daily_message_limit: "required",
                free_credits: "required",
                daily_conversation_limit: "required",
                monthly_message_limit: "required",
                monthly_conversation_limit: "required",
                automation_limit: "required",
                automation_action_limit: "required",
                segment_limit: "required",
            },
            messages: {
                pkg_name: "<?php echo e(trans('packages.add_package.validation_message.pkg_name')); ?>",
                role_id: "<?php echo e(trans('packages.add_package.validation_message.role_id')); ?>",
                price_per_message: "<?php echo e(trans('packages.add_package.validation_message.price_per_message')); ?>",
                daily_message_limit: "<?php echo e(trans('packages.add_package.validation_message.daily_message_limit')); ?>",
                free_credits: "<?php echo e(trans('packages.add_package.validation_message.free_credits')); ?>",
                daily_conversation_limit: "<?php echo e(trans('packages.add_package.validation_message.daily_conversation_limit')); ?>",
                monthly_message_limit: "<?php echo e(trans('packages.add_package.validation_message.monthly_message_limit')); ?>",
                monthly_conversation_limit: "<?php echo e(trans('packages.add_package.validation_message.monthly_conversation_limit')); ?>",
                automation_limit: "<?php echo e(trans('packages.add_package.validation_message.automation_limit')); ?>",
                automation_action_limit: "<?php echo e(trans('packages.add_package.validation_message.automation_action_limit')); ?>",
                segment_limit: "<?php echo e(trans('packages.add_package.validation_message.segment_limit')); ?>",
            },
            submitHandler: function (form) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('save.package')); ?>",
                    data: $("#frmPackages").serialize(),
                    cache: false,
                    dataType: 'json',
                    success: function (data) {
                        if (data.status == "success") {
                            var msgClass = 'success';
                        } else {
                            var msgClass = 'error';
                        }
                        Command: toastr[msgClass](data.message + '...');
                        if (data.status == "success") {
                            window.setTimeout(function () {
                              window.location.href = "<?php echo e(url('packages/view')); ?>";
                          }, 3000);  
                        }
                        
                    }
                });
            }
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="row g-5 g-xl-10">
    <div class="col-xl-12 col-md-6 mb-md-5">
        <?php echo $__env->make('partials.title_description', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    <div class="col-md-8 mb-md-5">
        <div class="card">
            <div class="card-header">
                <div class="card-title m-0">
                    <h3><?php echo e($title); ?></h3>
                </div>
            </div>
                
            <form id="frmPackages" name="frmPackages" class="form" method="post" action="" enctype="multipart/form-data">
                <input type="hidden" id="_token" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" value="<?php echo e($id); ?>" id="id" name="id">
                <div class="card-body border-top p-9">              
                    <div class="row mb-6">
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.name')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="text" name="pkg_name" id="pkg_name" value="<?php echo e((isset($pakchage['pkg_name']) ? $pakchage['pkg_name']:"")); ?>" class="form-control bg-transparent" placeholder="<?php echo e(trans('packages.add_package.name')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.role')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                            <div class="fv-row mb-0 fv-plugins-icon-container">
                                <select name="role_id" id="role_id"  class="form-select form-select-solid form-select-lg" aria-label="Choose-Role"data-control="select2" data-placeholder="Choose Role..." aria-label="<?php echo e(trans('packages.add_package.role')); ?>" data-placeholder="<?php echo e(trans('packages.add_package.role')); ?>">
                                    <option value=""><?php echo e(trans('packages.add_package.role')); ?></option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role['id']); ?>" <?php if(isset($pakchage['role_id']) && $pakchage['role_id']==$role['id']): ?> selected="" <?php endif; ?>><?php echo e($role['role_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="fv-plugins-message-container invalid-feedback"></div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.price_per_message')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="text" name="price_per_message" id="price_per_message" value="<?php echo e((isset($pakchage['price_per_message']) ? $pakchage['price_per_message']:"")); ?>" class="form-control bg-transparent" placeholder="<?php echo e(trans('packages.add_package.price_per_message')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.daily_message_limit')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="number" name="daily_message_limit" value="<?php echo e((isset($pakchage['daily_message_limit']) ? $pakchage['daily_message_limit']:"")); ?>" id="daily_message_limit" class="form-control bg-transparent" placeholder="<?php echo e(trans('packages.add_package.daily_message_limit')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.free_credits')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="number" name="free_credits" id="free_credits" value="<?php echo e((isset($pakchage['free_credits']) ? $pakchage['free_credits']:"")); ?>" class="form-control bg-transparent" placeholder="<?php echo e(trans('packages.add_package.free_credits')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.daily_conversation_limit')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="number" name="daily_conversation_limit" value="<?php echo e((isset($pakchage['daily_conversation_limit']) ? $pakchage['daily_conversation_limit']:"")); ?>" id="daily_conversation_limit" class="form-control bg-transparent" placeholder="<?php echo e(trans('packages.add_package.daily_conversation_limit')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.monthly_message_limit')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="number" name="monthly_message_limit" id="monthly_message_limit" value="<?php echo e((isset($pakchage['monthly_message_limit']) ? $pakchage['monthly_message_limit']:"")); ?>" class="form-control bg-transparent" placeholder="<?php echo e(trans('packages.add_package.monthly_message_limit')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.monthly_conversation_limit')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="number" name="monthly_conversation_limit" value="<?php echo e((isset($pakchage['monthly_conversation_limit']) ? $pakchage['monthly_conversation_limit']:"")); ?>" id="monthly_conversation_limit" class="form-control bg-transparent" placeholder="<?php echo e(trans('packages.add_package.monthly_conversation_limit')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.automation_limit')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="number" name="automation_limit" id="automation_limit" value="<?php echo e((isset($pakchage['automation_limit']) ? $pakchage['automation_limit']:"")); ?>" class="form-control bg-transparent" placeholder="<?php echo e(trans('packages.add_package.automation_limit')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.automation_action_limit')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="number" name="automation_action_limit" value="<?php echo e((isset($pakchage['automation_action_limit']) ? $pakchage['automation_action_limit']:"")); ?>" id="automation_action_limit" class="form-control bg-transparent" placeholder="<?php echo e(trans('packages.add_package.automation_action_limit')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.segment_limit')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="number" name="segment_limit" value="<?php echo e((isset($pakchage['segment_limit']) ? $pakchage['segment_limit']:"")); ?>" id="segment_limit" class="form-control bg-transparent" placeholder="<?php echo e(trans('packages.add_package.segment_limit')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.whmcs_pkg_link')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="text" name="whmcs_pkg_link" value="<?php echo e((isset($pakchage['whmcs_pkg_link']) ? $pakchage['whmcs_pkg_link']:"")); ?>" id="whmcs_pkg_link" class="form-control bg-transparent" placeholder="<?php echo e(trans('packages.add_package.whmcs_pkg_link')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-6">
                        <div class="col-lg-12">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.billing_pid')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                        </div>
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="number" name="billing_pid" id="billing_pid" value="<?php echo e((isset($pakchage['billing_pid']) ? $pakchage['billing_pid']:"")); ?>" class="form-control bg-transparent" placeholder="<?php echo e(trans('packages.add_package.billing_pid')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.delivery_notification')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-check form-check-solid col-form-label form-switch fv-row">
                                <input class="form-check-input w-45px h-30px" type="checkbox" name="delivery_notification" id="delivery_notification" <?php if(isset($pakchage['delivery_notification']) && $pakchage['delivery_notification']==1): ?> checked <?php endif; ?> >
                                <label class="form-check-label" for="up_fdns"></label>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.read_notification')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-check form-check-solid col-form-label form-switch fv-row">
                                <input class="form-check-input w-45px h-30px" type="checkbox" name="read_notification" id="read_notification" <?php if(isset($pakchage['delivery_notification']) && $pakchage['delivery_notification']===1): ?> checked <?php endif; ?> >
                                <label class="form-check-label" for="up_fdns"></label>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.web_hook')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-check form-check-solid col-form-label form-switch fv-row">
                                <input class="form-check-input w-45px h-30px" type="checkbox" name="web_hook" id="web_hook" <?php if(isset($pakchage['web_hook']) && $pakchage['web_hook']==1): ?> checked <?php endif; ?>>
                                <label class="form-check-label" for="up_fdns"></label>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('packages.add_package.status')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="Enter the text." aria-label="Enter the text."></i>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-check form-check-solid col-form-label form-switch fv-row">
                                <input class="form-check-input w-45px h-30px" type="checkbox" name="status" id="status" <?php if(isset($pakchage['status']) && $pakchage['status']==1): ?> checked <?php endif; ?>>
                                <label class="form-check-label" for="up_fdns"></label>
                            </div>
                        </div>
                    </div>







                </div>
                <div class="card-footer d-flex align-items-stretch justify-content-between flex-lg-grow-1">
                    <a href="<?php echo e(route('view.packages')); ?>" data-kt-contacts-type="cancel" class="btn btn-light me-3">Cancel</a>
                    <button type="submit" class="btn btn-primary">
                      <span class="indicator-label">Save Changes</span>
                      <span class="indicator-progress">Please wait... 
                        <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                      </span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\Mumara-WhatsApp\resources\views/pages/packages/addPackage.blade.php ENDPATH**/ ?>