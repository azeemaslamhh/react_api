<?php $__env->startSection('style'); ?>
<link href="/public/assets/css/datatables.bundle.css" rel="stylesheet" type="text/css" />
<link href="/public/assets/css/toastr.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="/public/assets/js/jquery.js"type="text/javascript"></script>
<script src="/public/assets/js/custom/datatables/datatables.bundle.js"type="text/javascript"></script>
<script src="/public/assets/js/toastr.min.js"></script>
<script>
    $(document).ready(function () {
        var objTable;
        objTable = $('#packageTable').dataTable({
            "aoColumnDefs": [{"bSortable": false, "aTargets": [0,6,7]}],
            "bProcessing": true,
            "bServerSide": true,
            "aaSorting": [[0, "DESC"]],
            "sPaginationType": "full_numbers",
            "sAjaxSource": "<?php echo e(route('get.packages')); ?>",
            "drawCallback": function( settings ) {
                KTMenu.createInstances();
                KTMenu.updateDropdowns();
            },
            columnDefs: [{
            targets: 0,
            className: 'form-check form-check-custom form-check-solid align-items-center'
          },{
            targets: 1,
            className: 'min-w-125px'
          },{
            targets: 2,
            className: 'min-w-100px'
          },{
            targets: 3,
            className: 'min-w-100px'
          },{
            targets: 4,
            className: 'min-w-100px'
          },{
            targets: 5,
            className: 'min-w-100px'
          },{
            targets: 6,
            className: 'text-end w-100px'
          }],
            "aLengthMenu": [[20, 50, 100, 500], [20, 50, 100, 500]]
        });
        ///$('#packageTable').DataTable();
        $(document).on("click", ".icnDelete", function (event) {
            var id = this.id;
            var objRow = objTable.fnGetPosition($(this).closest('tr')[0]);
            var result = confirm("<?php echo e(trans('file.delete_record')); ?>");
            if (result) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('delete.package')); ?>",
                    data: {'package_id': id, '_token': token},
                    cache: false,
                    dataType:'json',
                    success: function (data) {
                        var msgClasss = '';
                        if (data.status == "success") {
                            msgClasss = 'success';
                            objTable.fnDeleteRow(objRow);
                        } else {
                            msgClasss = 'error';
                        }
                        Command: toastr[msgClasss] (data.message);
                    }

                });

            }
        });
    });
</script>
<script>
    $('.checkbox-all-index').click(function () {
        if ($(this).is(':checked')) {
            $('.checkbox-index').not(':disabled').prop('checked', true);
        } else {
            $('.checkbox-index').prop('checked', false);
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-5 g-xl-10">
    <div class="col-xl-12 col-md-6 mb-md-5">
        <?php echo $__env->make('partials.title_description', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-xl-12 col-md-6 mb-md-5">
        <div class="card">
            <div class="card-header py-6">
                <div class="card-toolbar">
                  <div class="d-flex justify-content-end" data-kt-user-table-toolbar="base">
                    <a class="btn btn-primary" href="<?php echo e(route('add.package')); ?>">
                      Add Account</a>
                  </div>
                </div>
<!--                <div class="d-flex align-items-center position-relative my-1">
                  begin::Svg Icon | path: icons/duotune/general/gen021.svg
                  <span class="svg-icon svg-icon-3 position-absolute ms-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                      <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                      <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                    </svg>
                  </span>
                  end::Svg Icon
                  <input type="text" id="filter_search" class="form-control form-control-solid form-select-sm w-150px ps-9" placeholder="Search Here">
                </div>-->
              </div>
            <div class="card-body py-4">
                <div class="table-responsive">
                    <table id="packageTable" class="table align-middle table-row-dashed fs-6 gy-5 dataTable no-footer" role="table">
                        <thead>
                            <tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
                                <th  class="w-10px pe-2" tabindex="0">
                                    <div class="form-check form-check form-check-custom form-check-solid me-3">
                                        <input class="form-check-input checkbox-index  checkbox-all-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                                    </div>
                                </th>
                                <th tabindex="1"  class="min-w-125px"><?php echo e(trans('packages.view_package.name')); ?></th>
                                <th tabindex="2" class="min-w-100px"><?php echo e(trans('packages.view_package.role')); ?></th>
                                <th tabindex="3"  class="min-w-100px"><?php echo e(trans('packages.view_package.price_per_message')); ?></th>
                                <th tabindex="4" class="min-w-100px" ><?php echo e(trans('packages.view_package.free_credits')); ?></th>
                                <th tabindex="5" class="min-w-100px"><?php echo e(trans('packages.view_package.daily_message_limit')); ?></th>
                                <th ><?php echo e(trans('packages.view_package.actions')); ?></th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-bold" role="rowgroup">
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\Mumara-WhatsApp\resources\views/pages/packages/viewPackages.blade.php ENDPATH**/ ?>