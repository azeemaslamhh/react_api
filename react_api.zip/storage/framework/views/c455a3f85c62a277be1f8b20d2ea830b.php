<script src="/public/assets/js/plugins.bundle.js"></script>
<script src="/public/assets/js/scripts.bundle.js"></script>
<script src="/public/assets/js/widgets.bundle.js"></script>
<script src="/public/assets/js/select2.min.js"></script><?php /**PATH D:\Wamp\www\Mumara-WhatsApp\resources\views/partials/scripts.blade.php ENDPATH**/ ?>