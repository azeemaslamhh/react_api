<link href="/public/assets/font/font.css" rel="stylesheet" type="text/css" />
<link href="/public/assets/css/style.css" rel="stylesheet" type="text/css" />
<link href="/public/assets/css/custom.css" rel="stylesheet" type="text/css" />
<?php /**PATH D:\Wamp\www\Mumara-WhatsApp\resources\views/partials/styles.blade.php ENDPATH**/ ?>