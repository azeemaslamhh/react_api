<?php $__env->startSection('style'); ?>
<style>
  .table.gy-5 td, .table.gy-5 th {
    padding-bottom: 1rem;
    padding-top: 1rem;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  $('.checkbox-all-index').click(function () {
        if($(this).is(':checked')) {
            $('.checkbox-index').not(':disabled').prop('checked', true);
        } else {
            $('.checkbox-index').prop('checked', false);
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row g-5 g-xl-10">
    <div class="col-xl-12 col-md-6 mb-md-5">
        <div class="card">
          <div class="card-header border-0 pt-6">
            <div class="col-md-10">
              <div class="row">
                <div class="col-md-4">
                  <div class="card-title m-0">
                    <div class="d-flex align-items-center position-relative my-1">
                      <span class="svg-icon svg-icon-1 position-absolute ms-6">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                          <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                          <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                        </svg>
                      </span>
                      <input id="kt_filter_search" type="text" data-kt-user-table-filter="search" class="form-control form-control-solid w-250px ps-14" placeholder="Search Client" value="">
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <select name="Choose-Group" aria-label="Choose-Group" data-control="select2" data-placeholder="Choose Group.." class="form-select form-select-solid form-select-lg">
                    <option value="0">Select Status</option>
                    <option value="1">list 1</option>
                    <option value="2">list 2</option>
                    <option value="3">list 3</option>
                    <option value="4">local list</option>
                    <option value="5">List All Fields</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <select name="Choose-Group" aria-label="Choose-Group" data-control="select2" data-placeholder="Choose Group.." class="form-select form-select-solid form-select-lg">
                    <option value="0">Select Response</option>
                    <option value="1">list 1</option>
                    <option value="2">list 2</option>
                    <option value="3">list 3</option>
                    <option value="4">local list</option>
                    <option value="5">List All Fields</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <div class="card-title m-0">
                    <div class="d-flex align-items-center position-relative my-1">
                      <span class="svg-icon svg-icon-1 position-absolute ms-6">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                          <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                          <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                        </svg>
                      </span>
                      <input id="kt_filter_search" type="text" data-kt-user-table-filter="search" class="form-control form-control-solid w-250px ps-14" placeholder="Search" value="">
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <select name="Choose-Group" aria-label="Choose-Group" data-control="select2" data-placeholder="Choose Group.." class="form-select form-select-solid form-select-lg">
                    <option value="0">Select Sender ID</option>
                    <option value="1">list 1</option>
                    <option value="2">list 2</option>
                    <option value="3">list 3</option>
                    <option value="4">local list</option>
                    <option value="5">List All Fields</option>
                  </select>
                </div>
                <div class="col-md-4">
                  <input type="number" class="select2-selection select2-selection--single form-select form-select-solid lh-1 py-3" placeholder="Numbers" value="" style="background-image: none;padding: 0.775rem 1rem;">
                </div>
              </div>
            </div>
            <div class="col-md-2 ps-10">
              <div class="row">
                <div class="card-toolbar">
                  <div class="d-flex justify-content-end" data-kt-user-table-toolbar="base">
                    <a class="btn btn-primary btn-sm" href="/list/add">
                      <span class="svg-icon svg-icon-2">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                          <rect opacity="0.5" x="11.364" y="20.364" width="16" height="2" rx="1" transform="rotate(-90 11.364 20.364)" fill="currentColor"></rect>
                          <rect x="4.36396" y="11.364" width="16" height="2" rx="1" fill="currentColor"></rect>
                        </svg>
                      </span>Add List </a>
                  </div>
                </div>
                <div class="card-toolbar">
                  <div
                    data-kt-daterangepicker="true"
                    data-kt-daterangepicker-opens="left"
                    data-kt-daterangepicker-range="today"
                    class="btn btn-sm btn-light d-flex align-items-center px-4"
                  >
                    <div class="text-gray-600 fw-bold">
                      Loading date range...
                    </div>
                    <span class="svg-icon svg-icon-1 ms-2 me-0">
                      <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          opacity="0.3"
                          d="M21 22H3C2.4 22 2 21.6 2 21V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5V21C22 21.6 21.6 22 21 22Z"
                          fill="currentColor"
                        />
                        <path
                          d="M6 6C5.4 6 5 5.6 5 5V3C5 2.4 5.4 2 6 2C6.6 2 7 2.4 7 3V5C7 5.6 6.6 6 6 6ZM11 5V3C11 2.4 10.6 2 10 2C9.4 2 9 2.4 9 3V5C9 5.6 9.4 6 10 6C10.6 6 11 5.6 11 5ZM15 5V3C15 2.4 14.6 2 14 2C13.4 2 13 2.4 13 3V5C13 5.6 13.4 6 14 6C14.6 6 15 5.6 15 5ZM19 5V3C19 2.4 18.6 2 18 2C17.4 2 17 2.4 17 3V5C17 5.6 17.4 6 18 6C18.6 6 19 5.6 19 5Z"
                          fill="currentColor"
                        />
                        <path
                          d="M8.8 13.1C9.2 13.1 9.5 13 9.7 12.8C9.9 12.6 10.1 12.3 10.1 11.9C10.1 11.6 10 11.3 9.8 11.1C9.6 10.9 9.3 10.8 9 10.8C8.8 10.8 8.59999 10.8 8.39999 10.9C8.19999 11 8.1 11.1 8 11.2C7.9 11.3 7.8 11.4 7.7 11.6C7.6 11.8 7.5 11.9 7.5 12.1C7.5 12.2 7.4 12.2 7.3 12.3C7.2 12.4 7.09999 12.4 6.89999 12.4C6.69999 12.4 6.6 12.3 6.5 12.2C6.4 12.1 6.3 11.9 6.3 11.7C6.3 11.5 6.4 11.3 6.5 11.1C6.6 10.9 6.8 10.7 7 10.5C7.2 10.3 7.49999 10.1 7.89999 10C8.29999 9.90003 8.60001 9.80003 9.10001 9.80003C9.50001 9.80003 9.80001 9.90003 10.1 10C10.4 10.1 10.7 10.3 10.9 10.4C11.1 10.5 11.3 10.8 11.4 11.1C11.5 11.4 11.6 11.6 11.6 11.9C11.6 12.3 11.5 12.6 11.3 12.9C11.1 13.2 10.9 13.5 10.6 13.7C10.9 13.9 11.2 14.1 11.4 14.3C11.6 14.5 11.8 14.7 11.9 15C12 15.3 12.1 15.5 12.1 15.8C12.1 16.2 12 16.5 11.9 16.8C11.8 17.1 11.5 17.4 11.3 17.7C11.1 18 10.7 18.2 10.3 18.3C9.9 18.4 9.5 18.5 9 18.5C8.5 18.5 8.1 18.4 7.7 18.2C7.3 18 7 17.8 6.8 17.6C6.6 17.4 6.4 17.1 6.3 16.8C6.2 16.5 6.10001 16.3 6.10001 16.1C6.10001 15.9 6.2 15.7 6.3 15.6C6.4 15.5 6.6 15.4 6.8 15.4C6.9 15.4 7.00001 15.4 7.10001 15.5C7.20001 15.6 7.3 15.6 7.3 15.7C7.5 16.2 7.7 16.6 8 16.9C8.3 17.2 8.6 17.3 9 17.3C9.2 17.3 9.5 17.2 9.7 17.1C9.9 17 10.1 16.8 10.3 16.6C10.5 16.4 10.5 16.1 10.5 15.8C10.5 15.3 10.4 15 10.1 14.7C9.80001 14.4 9.50001 14.3 9.10001 14.3C9.00001 14.3 8.9 14.3 8.7 14.3C8.5 14.3 8.39999 14.3 8.39999 14.3C8.19999 14.3 7.99999 14.2 7.89999 14.1C7.79999 14 7.7 13.8 7.7 13.7C7.7 13.5 7.79999 13.4 7.89999 13.2C7.99999 13 8.2 13 8.5 13H8.8V13.1ZM15.3 17.5V12.2C14.3 13 13.6 13.3 13.3 13.3C13.1 13.3 13 13.2 12.9 13.1C12.8 13 12.7 12.8 12.7 12.6C12.7 12.4 12.8 12.3 12.9 12.2C13 12.1 13.2 12 13.6 11.8C14.1 11.6 14.5 11.3 14.7 11.1C14.9 10.9 15.2 10.6 15.5 10.3C15.8 10 15.9 9.80003 15.9 9.70003C15.9 9.60003 16.1 9.60004 16.3 9.60004C16.5 9.60004 16.7 9.70003 16.8 9.80003C16.9 9.90003 17 10.2 17 10.5V17.2C17 18 16.7 18.4 16.2 18.4C16 18.4 15.8 18.3 15.6 18.2C15.4 18.1 15.3 17.8 15.3 17.5Z"
                          fill="currentColor"
                        />
                      </svg>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
            <div class="card-body py-4">
              <div class="table-responsive">
                <table id="kt_table_users" class="table align-middle table-row-dashed fs-6 gy-5 dataTable no-footer" role="table">
                  <thead>
                    <tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
                      <th colspan="1" role="columnheader" class="w-10px pe-2">
                        <div class="form-check form-check form-check-custom form-check-solid me-3">
                          <input class="form-check-input checkbox-index checkbox-all-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                        </div>
                      </th>
                      <th colspan="1" role="columnheader" class="min-w-125px" style="cursor: pointer;">List Name</th>
                      <th colspan="1" role="columnheader" class="min-w-100px text-center" style="cursor: pointer;">Contacts</th>
                      <th colspan="1" role="columnheader" class="min-w-100px text-center" style="cursor: pointer;">Valid Contacts</th>
                      <th colspan="1" role="columnheader" class="min-w-100px text-center" style="cursor: pointer;">Status</th>
                      <th colspan="1" role="columnheader" class="min-w-100px" style="cursor: pointer;">Created at</th>
                      <th colspan="1" role="columnheader" class="text-end w-100px" style="cursor: pointer;">Actions</th>
                    </tr>
                  </thead>
                  <tbody class="text-gray-600 fw-bold" role="rowgroup">
                    <tr role="row">
                      <td role="cell" class="">
                        <div class="form-check form-check-custom form-check-solid">
                          <input class="form-check-input checkbox-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="d-flex align-items-center">
                          <div class="d-flex flex-column">
                            <span>list 3</span>
                          </div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <div class="text-primary text-hover-dark text-link">0</div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">0</div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <span class="badge badge-success fw-bolder">Active</span>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="badge badge-light fw-bolder">Jan 10, 2023 9:00 PM</div>
                      </td>
                      <td role="cell" class="text-end min-w-150px">
                        <a href="#" class="btn btn-light btn-active-light-primary btn-sm" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">Actions <span class="svg-icon svg-icon-5 m-0">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                              <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                            </svg>
                          </span>
                        </a>
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-175px py-4" data-kt-menu="true">
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="235">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M5 18.08V19h.92l9.06-9.06-.92-.92z" opacity="0.3" fill="currentColor"></path>
                                <path d="M20.71 7.04a.996.996 0 000-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29s-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM5.92 19H5v-.92l9.06-9.06.92.92L5.92 19z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Edit List</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-kt-users-table-filter="delete_row">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M8 9h8v10H8z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15.5 4l-1-1h-5l-1 1H5v2h14V4zM6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Delete</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="235">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--upload">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M9.83 8H11v6h2V8h1.17L12 5.83z" opacity="0.3" fill="currentColor"></path>
                                <path d="M12 3l-7 7h4v6h6v-6h4l-7-7zm1 5v6h-2V8H9.83L12 5.83 14.17 8H13zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Import Contacts</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="235">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--download">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M13 9V5h-2v6H9.83L12 13.17 14.17 11H13z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15 9V3H9v6H5l7 7 7-7h-4zm-3 4.17L9.83 11H11V5h2v6h1.17L12 13.17zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Export Contacts</span>
                            </a>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr role="row">
                      <td role="cell" class="">
                        <div class="form-check form-check-custom form-check-solid">
                          <input class="form-check-input checkbox-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="d-flex align-items-center">
                          <div class="d-flex flex-column">
                            <span>test company abcd</span>
                          </div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <div class="text-primary text-hover-dark text-link">0</div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">0</div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <span class="badge badge-success fw-bolder">Active</span>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="badge badge-light fw-bolder">Jan 9, 2023 8:38 PM</div>
                      </td>
                      <td role="cell" class="text-end min-w-150px">
                        <a href="#" class="btn btn-light btn-active-light-primary btn-sm" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">Actions <span class="svg-icon svg-icon-5 m-0">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                              <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                            </svg>
                          </span>
                        </a>
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-175px py-4" data-kt-menu="true">
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="231">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M5 18.08V19h.92l9.06-9.06-.92-.92z" opacity="0.3" fill="currentColor"></path>
                                <path d="M20.71 7.04a.996.996 0 000-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29s-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM5.92 19H5v-.92l9.06-9.06.92.92L5.92 19z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Edit List</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-kt-users-table-filter="delete_row">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M8 9h8v10H8z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15.5 4l-1-1h-5l-1 1H5v2h14V4zM6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Delete</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="231">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--upload">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M9.83 8H11v6h2V8h1.17L12 5.83z" opacity="0.3" fill="currentColor"></path>
                                <path d="M12 3l-7 7h4v6h6v-6h4l-7-7zm1 5v6h-2V8H9.83L12 5.83 14.17 8H13zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Import Contacts</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="231">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--download">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M13 9V5h-2v6H9.83L12 13.17 14.17 11H13z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15 9V3H9v6H5l7 7 7-7h-4zm-3 4.17L9.83 11H11V5h2v6h1.17L12 13.17zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Export Contacts</span>
                            </a>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr role="row">
                      <td role="cell" class="">
                        <div class="form-check form-check-custom form-check-solid">
                          <input class="form-check-input checkbox-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="d-flex align-items-center">
                          <div class="d-flex flex-column">
                            <span>list name 1</span>
                          </div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <div class="text-primary text-hover-dark text-link">0</div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">0</div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <span class="badge badge-success fw-bolder">Active</span>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="badge badge-light fw-bolder">Jan 5, 2023 10:03 PM</div>
                      </td>
                      <td role="cell" class="text-end min-w-150px">
                        <a href="#" class="btn btn-light btn-active-light-primary btn-sm" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">Actions <span class="svg-icon svg-icon-5 m-0">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                              <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                            </svg>
                          </span>
                        </a>
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-175px py-4" data-kt-menu="true">
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="226">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M5 18.08V19h.92l9.06-9.06-.92-.92z" opacity="0.3" fill="currentColor"></path>
                                <path d="M20.71 7.04a.996.996 0 000-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29s-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM5.92 19H5v-.92l9.06-9.06.92.92L5.92 19z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Edit List</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-kt-users-table-filter="delete_row">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M8 9h8v10H8z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15.5 4l-1-1h-5l-1 1H5v2h14V4zM6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Delete</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="226">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--upload">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M9.83 8H11v6h2V8h1.17L12 5.83z" opacity="0.3" fill="currentColor"></path>
                                <path d="M12 3l-7 7h4v6h6v-6h4l-7-7zm1 5v6h-2V8H9.83L12 5.83 14.17 8H13zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Import Contacts</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="226">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--download">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M13 9V5h-2v6H9.83L12 13.17 14.17 11H13z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15 9V3H9v6H5l7 7 7-7h-4zm-3 4.17L9.83 11H11V5h2v6h1.17L12 13.17zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Export Contacts</span>
                            </a>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr role="row">
                      <td role="cell" class="">
                        <div class="form-check form-check-custom form-check-solid">
                          <input class="form-check-input checkbox-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="d-flex align-items-center">
                          <div class="d-flex flex-column">
                            <span>local list</span>
                          </div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <div class="text-primary text-hover-dark text-link">0</div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">0</div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <span class="badge badge-success fw-bolder">Active</span>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="badge badge-light fw-bolder">Jan 5, 2023 12:53 AM</div>
                      </td>
                      <td role="cell" class="text-end min-w-150px">
                        <a href="#" class="btn btn-light btn-active-light-primary btn-sm" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">Actions <span class="svg-icon svg-icon-5 m-0">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                              <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                            </svg>
                          </span>
                        </a>
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-175px py-4" data-kt-menu="true">
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="224">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M5 18.08V19h.92l9.06-9.06-.92-.92z" opacity="0.3" fill="currentColor"></path>
                                <path d="M20.71 7.04a.996.996 0 000-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29s-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM5.92 19H5v-.92l9.06-9.06.92.92L5.92 19z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Edit List</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-kt-users-table-filter="delete_row">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M8 9h8v10H8z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15.5 4l-1-1h-5l-1 1H5v2h14V4zM6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Delete</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="224">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--upload">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M9.83 8H11v6h2V8h1.17L12 5.83z" opacity="0.3" fill="currentColor"></path>
                                <path d="M12 3l-7 7h4v6h6v-6h4l-7-7zm1 5v6h-2V8H9.83L12 5.83 14.17 8H13zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Import Contacts</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="224">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--download">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M13 9V5h-2v6H9.83L12 13.17 14.17 11H13z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15 9V3H9v6H5l7 7 7-7h-4zm-3 4.17L9.83 11H11V5h2v6h1.17L12 13.17zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Export Contacts</span>
                            </a>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr role="row">
                      <td role="cell" class="">
                        <div class="form-check form-check-custom form-check-solid">
                          <input class="form-check-input checkbox-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="d-flex align-items-center">
                          <div class="d-flex flex-column">
                            <span>list 2</span>
                          </div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <div class="text-primary text-hover-dark text-link">0</div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">0</div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <span class="badge badge-success fw-bolder">Active</span>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="badge badge-light fw-bolder">Jan 5, 2023 12:53 AM</div>
                      </td>
                      <td role="cell" class="text-end min-w-150px">
                        <a href="#" class="btn btn-light btn-active-light-primary btn-sm" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">Actions <span class="svg-icon svg-icon-5 m-0">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                              <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                            </svg>
                          </span>
                        </a>
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-175px py-4" data-kt-menu="true">
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="223">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M5 18.08V19h.92l9.06-9.06-.92-.92z" opacity="0.3" fill="currentColor"></path>
                                <path d="M20.71 7.04a.996.996 0 000-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29s-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM5.92 19H5v-.92l9.06-9.06.92.92L5.92 19z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Edit List</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-kt-users-table-filter="delete_row">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M8 9h8v10H8z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15.5 4l-1-1h-5l-1 1H5v2h14V4zM6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Delete</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="223">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--upload">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M9.83 8H11v6h2V8h1.17L12 5.83z" opacity="0.3" fill="currentColor"></path>
                                <path d="M12 3l-7 7h4v6h6v-6h4l-7-7zm1 5v6h-2V8H9.83L12 5.83 14.17 8H13zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Import Contacts</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="223">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--download">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M13 9V5h-2v6H9.83L12 13.17 14.17 11H13z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15 9V3H9v6H5l7 7 7-7h-4zm-3 4.17L9.83 11H11V5h2v6h1.17L12 13.17zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Export Contacts</span>
                            </a>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr role="row">
                      <td role="cell" class="">
                        <div class="form-check form-check-custom form-check-solid">
                          <input class="form-check-input checkbox-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="d-flex align-items-center">
                          <div class="d-flex flex-column">
                            <span>list 1</span>
                          </div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <div class="text-primary text-hover-dark text-link">0</div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">0</div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <span class="badge badge-success fw-bolder">Active</span>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="badge badge-light fw-bolder">Jan 5, 2023 12:52 AM</div>
                      </td>
                      <td role="cell" class="text-end min-w-150px">
                        <a href="#" class="btn btn-light btn-active-light-primary btn-sm" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">Actions <span class="svg-icon svg-icon-5 m-0">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                              <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                            </svg>
                          </span>
                        </a>
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-175px py-4" data-kt-menu="true">
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="222">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M5 18.08V19h.92l9.06-9.06-.92-.92z" opacity="0.3" fill="currentColor"></path>
                                <path d="M20.71 7.04a.996.996 0 000-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29s-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM5.92 19H5v-.92l9.06-9.06.92.92L5.92 19z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Edit List</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-kt-users-table-filter="delete_row">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M8 9h8v10H8z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15.5 4l-1-1h-5l-1 1H5v2h14V4zM6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Delete</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="222">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--upload">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M9.83 8H11v6h2V8h1.17L12 5.83z" opacity="0.3" fill="currentColor"></path>
                                <path d="M12 3l-7 7h4v6h6v-6h4l-7-7zm1 5v6h-2V8H9.83L12 5.83 14.17 8H13zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Import Contacts</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="222">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--download">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M13 9V5h-2v6H9.83L12 13.17 14.17 11H13z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15 9V3H9v6H5l7 7 7-7h-4zm-3 4.17L9.83 11H11V5h2v6h1.17L12 13.17zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Export Contacts</span>
                            </a>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr role="row">
                      <td role="cell" class="">
                        <div class="form-check form-check-custom form-check-solid">
                          <input class="form-check-input checkbox-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="d-flex align-items-center">
                          <div class="d-flex flex-column">
                            <span>list 123</span>
                          </div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <div class="text-primary text-hover-dark text-link">0</div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">0</div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <span class="badge badge-success fw-bolder">Active</span>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="badge badge-light fw-bolder">Jan 5, 2023 12:52 AM</div>
                      </td>
                      <td role="cell" class="text-end min-w-150px">
                        <a href="#" class="btn btn-light btn-active-light-primary btn-sm" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">Actions <span class="svg-icon svg-icon-5 m-0">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                              <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                            </svg>
                          </span>
                        </a>
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-175px py-4" data-kt-menu="true">
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="221">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M5 18.08V19h.92l9.06-9.06-.92-.92z" opacity="0.3" fill="currentColor"></path>
                                <path d="M20.71 7.04a.996.996 0 000-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29s-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM5.92 19H5v-.92l9.06-9.06.92.92L5.92 19z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Edit List</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-kt-users-table-filter="delete_row">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M8 9h8v10H8z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15.5 4l-1-1h-5l-1 1H5v2h14V4zM6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Delete</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="221">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--upload">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M9.83 8H11v6h2V8h1.17L12 5.83z" opacity="0.3" fill="currentColor"></path>
                                <path d="M12 3l-7 7h4v6h6v-6h4l-7-7zm1 5v6h-2V8H9.83L12 5.83 14.17 8H13zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Import Contacts</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="221">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--download">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M13 9V5h-2v6H9.83L12 13.17 14.17 11H13z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15 9V3H9v6H5l7 7 7-7h-4zm-3 4.17L9.83 11H11V5h2v6h1.17L12 13.17zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Export Contacts</span>
                            </a>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr role="row">
                      <td role="cell" class="">
                        <div class="form-check form-check-custom form-check-solid">
                          <input class="form-check-input checkbox-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="d-flex align-items-center">
                          <div class="d-flex flex-column">
                            <span>abcd</span>
                          </div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <div class="text-primary text-hover-dark text-link">0</div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">0</div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <span class="badge badge-success fw-bolder">Active</span>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="badge badge-light fw-bolder">Jan 5, 2023 12:52 AM</div>
                      </td>
                      <td role="cell" class="text-end min-w-150px">
                        <a href="#" class="btn btn-light btn-active-light-primary btn-sm" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">Actions <span class="svg-icon svg-icon-5 m-0">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                              <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                            </svg>
                          </span>
                        </a>
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-175px py-4" data-kt-menu="true">
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="220">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M5 18.08V19h.92l9.06-9.06-.92-.92z" opacity="0.3" fill="currentColor"></path>
                                <path d="M20.71 7.04a.996.996 0 000-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29s-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM5.92 19H5v-.92l9.06-9.06.92.92L5.92 19z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Edit List</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-kt-users-table-filter="delete_row">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M8 9h8v10H8z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15.5 4l-1-1h-5l-1 1H5v2h14V4zM6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Delete</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="220">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--upload">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M9.83 8H11v6h2V8h1.17L12 5.83z" opacity="0.3" fill="currentColor"></path>
                                <path d="M12 3l-7 7h4v6h6v-6h4l-7-7zm1 5v6h-2V8H9.83L12 5.83 14.17 8H13zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Import Contacts</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="220">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--download">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M13 9V5h-2v6H9.83L12 13.17 14.17 11H13z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15 9V3H9v6H5l7 7 7-7h-4zm-3 4.17L9.83 11H11V5h2v6h1.17L12 13.17zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Export Contacts</span>
                            </a>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr role="row">
                      <td role="cell" class="">
                        <div class="form-check form-check-custom form-check-solid">
                          <input class="form-check-input checkbox-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="d-flex align-items-center">
                          <div class="d-flex flex-column">
                            <span>test list 1</span>
                          </div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <div class="text-primary text-hover-dark text-link">0</div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">0</div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <span class="badge badge-success fw-bolder">Active</span>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="badge badge-light fw-bolder">Jan 5, 2023 12:50 AM</div>
                      </td>
                      <td role="cell" class="text-end min-w-150px">
                        <a href="#" class="btn btn-light btn-active-light-primary btn-sm" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">Actions <span class="svg-icon svg-icon-5 m-0">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                              <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                            </svg>
                          </span>
                        </a>
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-175px py-4" data-kt-menu="true">
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="219">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M5 18.08V19h.92l9.06-9.06-.92-.92z" opacity="0.3" fill="currentColor"></path>
                                <path d="M20.71 7.04a.996.996 0 000-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29s-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM5.92 19H5v-.92l9.06-9.06.92.92L5.92 19z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Edit List</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-kt-users-table-filter="delete_row">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M8 9h8v10H8z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15.5 4l-1-1h-5l-1 1H5v2h14V4zM6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Delete</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="219">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--upload">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M9.83 8H11v6h2V8h1.17L12 5.83z" opacity="0.3" fill="currentColor"></path>
                                <path d="M12 3l-7 7h4v6h6v-6h4l-7-7zm1 5v6h-2V8H9.83L12 5.83 14.17 8H13zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Import Contacts</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="219">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--download">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M13 9V5h-2v6H9.83L12 13.17 14.17 11H13z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15 9V3H9v6H5l7 7 7-7h-4zm-3 4.17L9.83 11H11V5h2v6h1.17L12 13.17zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Export Contacts</span>
                            </a>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr role="row">
                      <td role="cell" class="">
                        <div class="form-check form-check-custom form-check-solid">
                          <input class="form-check-input checkbox-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="d-flex align-items-center">
                          <div class="d-flex flex-column">
                            <span>usman4</span>
                          </div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <div class="text-primary text-hover-dark text-link">0</div>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">0</div>
                      </td>
                      <td role="cell" class="">
                        <div class="text-center">
                          <span class="badge badge-success fw-bolder">Active</span>
                        </div>
                      </td>
                      <td role="cell" class="">
                        <div class="badge badge-light fw-bolder">Jan 5, 2023 12:37 AM</div>
                      </td>
                      <td role="cell" class="text-end min-w-150px">
                        <a href="#" class="btn btn-light btn-active-light-primary btn-sm" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">Actions <span class="svg-icon svg-icon-5 m-0">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="mh-50px">
                              <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                            </svg>
                          </span>
                        </a>
                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-bold fs-7 w-175px py-4" data-kt-menu="true">
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="218">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M5 18.08V19h.92l9.06-9.06-.92-.92z" opacity="0.3" fill="currentColor"></path>
                                <path d="M20.71 7.04a.996.996 0 000-1.41l-2.34-2.34c-.2-.2-.45-.29-.71-.29s-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM5.92 19H5v-.92l9.06-9.06.92.92L5.92 19z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Edit List</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-kt-users-table-filter="delete_row">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M8 9h8v10H8z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15.5 4l-1-1h-5l-1 1H5v2h14V4zM6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM8 9h8v10H8V9z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Delete</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="218">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--upload">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M9.83 8H11v6h2V8h1.17L12 5.83z" opacity="0.3" fill="currentColor"></path>
                                <path d="M12 3l-7 7h4v6h6v-6h4l-7-7zm1 5v6h-2V8H9.83L12 5.83 14.17 8H13zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Import Contacts</span>
                            </a>
                          </div>
                          <div class="menu-item px-3">
                            <a class="menu-link px-3" data-id="218">
                              <svg xmlns="http://www.w3.org/2000/svg" height="1.4em" viewBox="0 0 24 24" width="1.4em" class="text-active-light-primary me-2" data-name="Material--download">
                                <path d="M0 0h24v24H0V0z" fill="none"></path>
                                <path d="M13 9V5h-2v6H9.83L12 13.17 14.17 11H13z" opacity="0.3" fill="currentColor"></path>
                                <path d="M15 9V3H9v6H5l7 7 7-7h-4zm-3 4.17L9.83 11H11V5h2v6h1.17L12 13.17zM5 18h14v2H5z" fill="currentColor"></path>
                              </svg>
                              <span class=" me-2">Export Contacts</span>
                            </a>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="row">
                <div class="col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start">
                  <div class="page-filter me-3">
                    <select data-kt-user-table-filter="items_per_page" class="form-select form-select-solid form-select-sm">
                      <option value="10" selected="">10</option>
                      <option value="25">25</option>
                      <option value="50">50</option>
                      <option value="100">100</option>
                    </select>
                  </div>
                  <span class="text-muted fw-normal">Showing 1 to 10 of 13 entries</span>
                </div>
                <div class="col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end">
                  <div id="kt_table_users_paginate">
                    <ul class="pagination">
											<li class="page-item previous">
												<a href="#" class="page-link">
													<i class="previous"></i>
												</a>
											</li>
											<li class="page-item active">
												<a href="#" class="page-link">1</a>
											</li>
											<li class="page-item">
												<a href="#" class="page-link">2</a>
											</li>
											<li class="page-item">
												<a href="#" class="page-link">3</a>
											</li>
											<li class="page-item next">
												<a href="#" class="page-link">
													<i class="next"></i>
												</a>
											</li>
										</ul>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\Mumara-WhatsApp\resources\views/pages/lists/index.blade.php ENDPATH**/ ?>