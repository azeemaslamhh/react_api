<div id="kt_header" class="header align-items-stretch">
    <div class="container-fluid d-flex align-items-stretch justify-content-between">
      <div class="d-flex align-items-center d-lg-none ms-n2 me-2" title="Show aside menu">
        <div class="btn btn-icon btn-active-light-primary w-30px h-30px w-md-40px h-md-40px"
          id="kt_aside_mobile_toggle">
          <span class="svg-icon svg-icon-1">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z"
                fill="black"></path>
              <path opacity="0.3"
                d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z"
                fill="black"></path>
            </svg>
          </span>
        </div>
      </div>
      <div class="d-flex align-items-center flex-grow-1 flex-lg-grow-0">
        <a href="./index.html" class="d-lg-none">
          <img alt="Logo" src="/public/assets/images/logo_dark.png" class="h-30px" />
        </a>
      </div>
      <div class="d-flex align-items-stretch justify-content-between flex-lg-grow-1">
        <div class="d-flex align-items-stretch" id="kt_header_nav">
          <div class="header-menu align-items-stretch" data-kt-drawer="true" data-kt-drawer-name="header-menu"
            data-kt-drawer-activate="{default: true, lg: false}" data-kt-drawer-overlay="true"
            data-kt-drawer-width="{default:'200px', '300px': '250px'}" data-kt-drawer-direction="end"
            data-kt-drawer-toggle="#kt_header_menu_mobile_toggle" data-kt-swapper="true"
            data-kt-swapper-mode="prepend" data-kt-swapper-parent="{default: '#kt_body', lg: '#kt_header_nav'}">
          </div>
        </div>
        <div class="d-flex align-items-stretch flex-shrink-0">
          <div class="d-flex align-items-center ms-1 ms-lg-3">
            <div
              class="btn btn-icon btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px position-relative"
              data-kt-menu-trigger="click" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
              <span class="svg-icon svg-icon-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
                  version="1.1" class="kt-svg-icon">
                  <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <rect id="bound" x="0" y="0" width="24" height="24"></rect>
                    <path
                      d="M4,9.67471899 L10.880262,13.6470401 C10.9543486,13.689814 11.0320333,13.7207107 11.1111111,13.740321 L11.1111111,21.4444444 L4.49070127,17.526473 C4.18655139,17.3464765 4,17.0193034 4,16.6658832 L4,9.67471899 Z M20,9.56911707 L20,16.6658832 C20,17.0193034 19.8134486,17.3464765 19.5092987,17.526473 L12.8888889,21.4444444 L12.8888889,13.6728275 C12.9050191,13.6647696 12.9210067,13.6561758 12.9368301,13.6470401 L20,9.56911707 Z"
                      id="Combined-Shape" fill="#000000"></path>
                    <path
                      d="M4.21611835,7.74669402 C4.30015839,7.64056877 4.40623188,7.55087574 4.5299008,7.48500698 L11.5299008,3.75665466 C11.8237589,3.60013944 12.1762411,3.60013944 12.4700992,3.75665466 L19.4700992,7.48500698 C19.5654307,7.53578262 19.6503066,7.60071528 19.7226939,7.67641889 L12.0479413,12.1074394 C11.9974761,12.1365754 11.9509488,12.1699127 11.9085461,12.2067543 C11.8661433,12.1699127 11.819616,12.1365754 11.7691509,12.1074394 L4.21611835,7.74669402 Z"
                      id="Path" fill="#000000" opacity="0.3"></path>
                  </g>
                </svg>
              </span>
            </div>
            
<div  class="menu menu-sub menu-sub-dropdown menu-column w-250px w-lg-400px quick-links" data-kt-menu="true" data-popper-placement="bottom-end">
<div class="d-flex flex-column flex-left bgi-no-repeat rounded-top px-9 py-10" style="background-image:url('/public/assets/images/pattern-1.jpg')">
<h3 class="text-white fw-bold"> Get Started </h3>
<div class="d-flex align-items-center flex-column mt-3 w-100">
        <div class="d-flex justify-content-between fw-bold fs-6 text-white opacity-75 w-100 mt-auto mb-2">
            <span>25%</span>
    <div class="h-8px mx-3 w-100 bg-white bg-opacity-50 rounded mt-2">
      <div class="bg-white rounded h-8px" role="progressbar" style="width: 25%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
    </div>
        </div> 
    </div>
</div>
<div class="tab-content tab-is">
<div class="kt-notification kt-margin-t-10 kt-margin-b-10 scroll scroll-y mh-350px m-0 p-3 initial-guide">
  <div class="col-md-12 setep_options">
    <div class="setepOptions option1 done">
    <div
      class="d-flex align-items-center justify-content-between collapsible toggle mb-0 text-link collapsed"
      data-bs-toggle="collapse"
      data-bs-target="#setup_1"
      aria-expanded="false"
    >
      <h3>
        <i class="fa fa-check"></i>
        <span class="option-title">Geoip Dependencies</span>
      </h3>
    </div>
    <div id="setup_1" class="fs-6 ms-1 collapse paraSetup">
      <div class="text-gray-600 fw-semibold fs-6 p-5">
      Download geo IP location for fast development
      <button
        type="button"
        class="btn btn-primary btn-sm mt-4 d-flex"
        id="download_dependencies"
      >
        Geoip Dependencies
      </button>
      <div
        class="alert alert-dismissible bg-light-danger d-flex flex-column flex-sm-row w-100 p-5 mt-3"
        id="geoipDownloadFailed"
      >
        <span
        class="svg-icon svg-icon-danger me-4 alert-icon"
        ></span>
        <div
        class="d-flex align-items-center pe-0 fw-normal text-dark fs-7"
        >
        <span>License Verification Failed</span>
        </div>
      </div>
      </div>
    </div>
    </div>
    <div class="setepOptions option2 done">
    <div
      class="d-flex align-items-center justify-content-between collapsible toggle mb-0 text-link collapsed"
      data-bs-toggle="collapse"
      data-bs-target="#setup_2"
      aria-expanded="false"
    >
      <h3>
        <i class="fa fa-check"></i>
        <span class="option-title">Sending Domain</span>
      </h3>
    </div>
    <div id="setup_2" class="fs-6 ms-1 collapse paraSetup">
      <div class="text-gray-600 fw-semibold fs-6 p-5">
      Sending domain appears as the sender’s domain when
      your recipients receive emails. E.g if a person
      receives an email from joseph@letscommunicate.com,
      the sending domain is letscommunicate.com.
      <button
        type="button"
        class="btn btn-primary btn-sm mt-4 d-flex"
        id="opts1"
        onclick='window.location.href="/domain/add"'
      >
        Add Sending Domain
      </button>
      </div>
    </div>
    </div>
    <div class="setepOptions option3">
    <div
      class="d-flex align-items-center justify-content-between collapsible toggle mb-0 text-link collapsed"
      data-bs-toggle="collapse"
      data-bs-target="#setup_3"
      aria-expanded="false"
    >
      <h3>
        <i class="fa fa-check"></i>
        <span class="option-title">Bounce Address</span>
      </h3>
    </div>
    <div id="setup_3" class="fs-6 ms-1 collapse">
      <div class="text-gray-600 fw-semibold fs-6 p-5">
      Bounce address is the mailbox where Mumara Site
      sends delivery reports of the failed attempts.
      <button
        type="button"
        class="btn btn-primary btn-sm mt-4 d-flex"
        id="opts2"
        onclick='window.location.href="/bounce/mailbox/add"'
      >
        Add a Bounce Address
      </button>
      </div>
    </div>
    </div>
    <div class="setepOptions option4">
    <div
      class="d-flex align-items-center justify-content-between collapsible toggle mb-0 text-link collapsed"
      data-bs-toggle="collapse"
      data-bs-target="#setup_4"
      aria-expanded="false"
    >
      <h3>
        <i class="fa fa-check"></i>
        <span class="option-title">Sending Node</span>
      </h3>
    </div>
    <div id="setup_4" class="fs-6 ms-1 collapse">
      <div class="text-gray-600 fw-semibold fs-6 p-5">
      Sending Node is your email courier and technically
      called an MTA. You can connect an SMTP or an ESP
      account from the supported providers.
      <button
        type="button"
        class="btn btn-primary btn-sm mt-4 d-flex"
        id="opts3"
        onclick='window.location.href="/node/list/view"'
      >
        Connect Sending Node
      </button>
      </div>
    </div>
    </div>
    <div class="setepOptions option5">
    <div
      class="d-flex align-items-center justify-content-between collapsible toggle mb-0 text-link collapsed"
      data-bs-toggle="collapse"
      data-bs-target="#setup_5"
      aria-expanded="false"
    >
      <h3>
        <i class="fa fa-check"></i>
        <span class="option-title">Contact List</span>
      </h3>
    </div>
    <div id="setup_5" class="fs-6 ms-1 collapse">
      <div class="text-gray-600 fw-semibold fs-6 p-5">
      Create a contact list that can store your
      contacts/subscribers information.
      <button
        type="button"
        class="btn btn-primary btn-sm mt-4 d-flex"
        id="opts4"
        onclick='window.location.href="/list/add"'
      >
        Add Contact List
      </button>
      </div>
    </div>
    </div>
    <div class="setepOptions option6">
    <div
      class="d-flex align-items-center justify-content-between collapsible toggle mb-0 text-link collapsed"
      data-bs-toggle="collapse"
      data-bs-target="#setup_6"
      aria-expanded="false"
    >
      <h3>
        <i class="fa fa-check"></i>
        <span class="option-title">Import Contacts</span>
      </h3>
    </div>
    <div id="setup_6" class="fs-6 ms-1 collapse">
      <div class="text-gray-600 fw-semibold fs-6 p-5">
      <span class="d-flex"
        >Add/Import your contacts whom you want to send
        your first broadcast.</span
      >
      <button
        type="button"
        class="btn btn-primary btn-sm mt-4"
        id="opts5"
        onclick='window.location.href="/contact/add"'
      >
        Add a Contact
      </button>
      <button
        type="button"
        class="btn btn-primary btn-sm mt-4"
        id="opts55"
        onclick='window.location.href="/contacts/import"'
      >
        Import Contacts
      </button>
      </div>
    </div>
    </div>
    <div class="setepOptions option7">
    <div
      class="d-flex align-items-center justify-content-between collapsible toggle mb-0 text-link collapsed"
      data-bs-toggle="collapse"
      data-bs-target="#setup_7"
      aria-expanded="false"
    >
      <h3>
        <i class="fa fa-check"></i>
        <span class="option-title">Create First Broadcast</span>
      </h3>
    </div>
    <div id="setup_7" class="fs-6 ms-1 collapse">
      <div class="text-gray-600 fw-semibold fs-6 p-5">
      Add/Import your contacts whom you want to send
      your first broadcast.
      <button
        type="button"
        class="btn btn-primary btn-sm mt-4 d-flex"
        id="opts6"
        onclick='window.location.href="/broadcast/add"'
      >
        Add New Broadcast
      </button>
      </div>
    </div>
    </div>
    <div class="setepOptions option8">
    <div
      class="d-flex align-items-center justify-content-between collapsible toggle mb-0 text-link collapsed"
      data-bs-toggle="collapse"
      data-bs-target="#setup_8"
      aria-expanded="false"
    >
      <h3>
        <i class="fa fa-check"></i>
        <span class="option-title">Schedule First Broadcast</span>
      </h3>
    </div>
    <div id="setup_8" class="fs-6 ms-1 collapse">
      <div class="text-gray-600 fw-semibold fs-6 p-5">
      You’re doing excellent job so far. It’s the time
      now to schedule a broadcast and see how does it
      perform.
      <button
        type="button"
        class="btn btn-primary btn-sm mt-4 d-flex"
        id="opts7"
        onclick='window.location.href="/schedule/new"'
      >
        Schedule Broadcast
      </button>
      </div>
    </div>
    </div>
  </div>
</div>
</div>
</div>
          </div>
          <div class="d-flex align-items-center ms-1 ms-lg-3">
            <div
              class="btn btn-icon btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px position-relative"
              data-kt-menu-trigger="click" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
              <span class="svg-icon svg-icon-1 fa-spin">
                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
                  version="1.1" class="kt-svg-icon">
                  <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <rect id="bound" x="0" y="0" width="24" height="24" />
                    <path
                      d="M18.6225,9.75 L18.75,9.75 C19.9926407,9.75 21,10.7573593 21,12 C21,13.2426407 19.9926407,14.25 18.75,14.25 L18.6854912,14.249994 C18.4911876,14.250769 18.3158978,14.366855 18.2393549,14.5454486 C18.1556809,14.7351461 18.1942911,14.948087 18.3278301,15.0846699 L18.372535,15.129375 C18.7950334,15.5514036 19.03243,16.1240792 19.03243,16.72125 C19.03243,17.3184208 18.7950334,17.8910964 18.373125,18.312535 C17.9510964,18.7350334 17.3784208,18.97243 16.78125,18.97243 C16.1840792,18.97243 15.6114036,18.7350334 15.1896699,18.3128301 L15.1505513,18.2736469 C15.008087,18.1342911 14.7951461,18.0956809 14.6054486,18.1793549 C14.426855,18.2558978 14.310769,18.4311876 14.31,18.6225 L14.31,18.75 C14.31,19.9926407 13.3026407,21 12.06,21 C10.8173593,21 9.81,19.9926407 9.81,18.75 C9.80552409,18.4999185 9.67898539,18.3229986 9.44717599,18.2361469 C9.26485393,18.1556809 9.05191298,18.1942911 8.91533009,18.3278301 L8.870625,18.372535 C8.44859642,18.7950334 7.87592081,19.03243 7.27875,19.03243 C6.68157919,19.03243 6.10890358,18.7950334 5.68746499,18.373125 C5.26496665,17.9510964 5.02757002,17.3784208 5.02757002,16.78125 C5.02757002,16.1840792 5.26496665,15.6114036 5.68716991,15.1896699 L5.72635306,15.1505513 C5.86570889,15.008087 5.90431906,14.7951461 5.82064513,14.6054486 C5.74410223,14.426855 5.56881236,14.310769 5.3775,14.31 L5.25,14.31 C4.00735931,14.31 3,13.3026407 3,12.06 C3,10.8173593 4.00735931,9.81 5.25,9.81 C5.50008154,9.80552409 5.67700139,9.67898539 5.76385306,9.44717599 C5.84431906,9.26485393 5.80570889,9.05191298 5.67216991,8.91533009 L5.62746499,8.870625 C5.20496665,8.44859642 4.96757002,7.87592081 4.96757002,7.27875 C4.96757002,6.68157919 5.20496665,6.10890358 5.626875,5.68746499 C6.04890358,5.26496665 6.62157919,5.02757002 7.21875,5.02757002 C7.81592081,5.02757002 8.38859642,5.26496665 8.81033009,5.68716991 L8.84944872,5.72635306 C8.99191298,5.86570889 9.20485393,5.90431906 9.38717599,5.82385306 L9.49484664,5.80114977 C9.65041313,5.71688974 9.7492905,5.55401473 9.75,5.3775 L9.75,5.25 C9.75,4.00735931 10.7573593,3 12,3 C13.2426407,3 14.25,4.00735931 14.25,5.25 L14.249994,5.31450877 C14.250769,5.50881236 14.366855,5.68410223 14.552824,5.76385306 C14.7351461,5.84431906 14.948087,5.80570889 15.0846699,5.67216991 L15.129375,5.62746499 C15.5514036,5.20496665 16.1240792,4.96757002 16.72125,4.96757002 C17.3184208,4.96757002 17.8910964,5.20496665 18.312535,5.626875 C18.7350334,6.04890358 18.97243,6.62157919 18.97243,7.21875 C18.97243,7.81592081 18.7350334,8.38859642 18.3128301,8.81033009 L18.2736469,8.84944872 C18.1342911,8.99191298 18.0956809,9.20485393 18.1761469,9.38717599 L18.1988502,9.49484664 C18.2831103,9.65041313 18.4459853,9.7492905 18.6225,9.75 Z"
                      id="Combined-Shape" fill="#000000" fill-rule="nonzero" opacity="0.3" />
                    <path
                      d="M12,15 C13.6568542,15 15,13.6568542 15,12 C15,10.3431458 13.6568542,9 12,9 C10.3431458,9 9,10.3431458 9,12 C9,13.6568542 10.3431458,15 12,15 Z"
                      id="Path" fill="#000000" />
                  </g>
                </svg>
              </span>
            </div>
            <div class="menu menu-sub menu-sub-dropdown menu-column w-350px w-lg-375px" data-kt-menu="true">
              <div class="d-flex flex-column bgi-no-repeat rounded-top"
                style="background-image: url('/public/assets/images/pattern-1.jpg')">
                <h3 class="text-white fw-bold px-9 mt-10 mb-6">
                  Processes
                  <span class="fs-8 opacity-75 ms-3 badge badge-light-info">10</span>
                </h3>
                <ul class="nav nav-line-tabs nav-line-tabs-2x nav-stretch fw-bold px-9">
                  <li class="nav-item">
                    <a class="nav-link text-white opacity-75 opacity-state-100 pb-4 active" data-bs-toggle="tab"
                      href="#issues">Isuues</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-white opacity-75 opacity-state-100 pb-4" data-bs-toggle="tab"
                      href="#proccesses">Running Processing
                    </a>
                  </li>
                </ul>
              </div>
              <div class="tab-content">
                <div class="tab-pane fade show active" id="issues" role="tabpanel">
                  <div class="scroll-y mh-325px my-5 px-3">
                    <div class="d-flex flex-stack py-4 px-5">
                      <div class="d-flex align-items-start">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-warning">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-times text-warning fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="d-flex flex-column">
                          <span class="fs-7 mb-1 text-gray-800 fw-semibold">
                            Expected response code 354 but got code "503",
                            with message "503 RCPT command expected"
                          </span>
                          <span class="fs-8 text-muted fw-semibold mb-1">Last Checked Jan 28, 2023 04:52:59 AM
                          </span>
                          <button type="button" class="btn btn-success btn-xs resolve-btn">
                            Mark Resolved
                          </button>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex flex-stack py-4 px-5">
                      <div class="d-flex align-items-start">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-warning">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-times text-warning fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="d-flex flex-column">
                          <span class="fs-7 mb-1 text-gray-800 fw-semibold">
                            Expected response code 354 but got code "503",
                            with message "503 RCPT command expected"
                          </span>
                          <span class="fs-8 text-muted fw-semibold mb-1">Last Checked Jan 26, 2023 11:45:55 PM
                          </span>
                          <button type="button" class="btn btn-success btn-xs resolve-btn">
                            Mark Resolved
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="py-3 text-center border-top">
                    <a href="#" class="btn btn-color-gray-600 btn-active-color-primary">
                      View All Issues
                      <span class="svg-icon svg-icon-5">
                        <i class="fa fa-arrow-right fs-8"></i>
                      </span>
                    </a>
                  </div>
                </div>
                <div class="tab-pane fade" id="proccesses" role="tabpanel">
                  <div class="scroll-y mh-325px my-5 px-8">
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-spinner fa-spin me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <div class="fs-6 text-gray-800 text-hover-primary fw-bold">
                            Database update in progress
                          </div>
                          <div class="text-gray-400 fs-7">
                            <span class="fw-semibold text-gray-500">
                              Just now
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-spinner fa-spin me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <div class="fs-6 text-gray-800 text-hover-primary fw-bold">
                            Running Campaign
                            <span class="text-gray-400 fs-8">(Test SAM )</span>
                          </div>
                          <div class="text-gray-400 fs-7">
                            <span class="fw-semibold text-gray-500">
                              5 minutes ago
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-spinner fa-spin me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <div class="fs-6 text-gray-800 text-hover-primary fw-bold">
                            Running Campaign
                            <span class="text-gray-400 fs-8">( New Sucscribers )</span>
                          </div>
                          <div class="text-gray-400 fs-7">
                            <span class="fw-semibold text-gray-500">
                              3 hours ago
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-spinner fa-spin me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <div class="fs-6 text-gray-800 text-hover-primary fw-bold">
                            Database update in progress
                          </div>
                          <div class="text-gray-400 fs-7">
                            <span class="fw-semibold text-gray-500">
                              15 hours ago
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-spinner fa-spin me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <div class="fs-6 text-gray-800 text-hover-primary fw-bold">
                            Running Campaign
                            <span class="text-gray-400 fs-8">( Old Sucscribers )</span>
                          </div>
                          <div class="text-gray-400 fs-7">
                            <span class="fw-semibold text-gray-500">
                              10 days ago
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-spinner fa-spin me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <div class="fs-6 text-gray-800 text-hover-primary fw-bold">
                            Running Campaign
                            <span class="text-gray-400 fs-8">( Holiday )</span>
                          </div>
                          <div class="text-gray-400 fs-7">
                            <span class="fw-semibold text-gray-500">
                              3 months ago
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="py-3 text-center border-top">
                    <a href="#" class="btn btn-color-gray-600 btn-active-color-primary">
                      View All Process
                      <span class="svg-icon svg-icon-5">
                        <i class="fa fa-arrow-right fs-8"></i>
                      </span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="d-flex align-items-center ms-1 ms-lg-3">
            <div
              class="btn btn-icon btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px position-relative"
              data-kt-menu-trigger="click" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
              <span class="svg-icon svg-icon-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M11.2929 2.70711C11.6834 2.31658 12.3166 2.31658 12.7071 2.70711L15.2929 5.29289C15.6834 5.68342 15.6834 6.31658 15.2929 6.70711L12.7071 9.29289C12.3166 9.68342 11.6834 9.68342 11.2929 9.29289L8.70711 6.70711C8.31658 6.31658 8.31658 5.68342 8.70711 5.29289L11.2929 2.70711Z"
                    fill="black"></path>
                  <path
                    d="M11.2929 14.7071C11.6834 14.3166 12.3166 14.3166 12.7071 14.7071L15.2929 17.2929C15.6834 17.6834 15.6834 18.3166 15.2929 18.7071L12.7071 21.2929C12.3166 21.6834 11.6834 21.6834 11.2929 21.2929L8.70711 18.7071C8.31658 18.3166 8.31658 17.6834 8.70711 17.2929L11.2929 14.7071Z"
                    fill="black"></path>
                  <path opacity="0.3"
                    d="M5.29289 8.70711C5.68342 8.31658 6.31658 8.31658 6.70711 8.70711L9.29289 11.2929C9.68342 11.6834 9.68342 12.3166 9.29289 12.7071L6.70711 15.2929C6.31658 15.6834 5.68342 15.6834 5.29289 15.2929L2.70711 12.7071C2.31658 12.3166 2.31658 11.6834 2.70711 11.2929L5.29289 8.70711Z"
                    fill="black"></path>
                  <path opacity="0.3"
                    d="M17.2929 8.70711C17.6834 8.31658 18.3166 8.31658 18.7071 8.70711L21.2929 11.2929C21.6834 11.6834 21.6834 12.3166 21.2929 12.7071L18.7071 15.2929C18.3166 15.6834 17.6834 15.6834 17.2929 15.2929L14.7071 12.7071C14.3166 12.3166 14.3166 11.6834 14.7071 11.2929L17.2929 8.70711Z"
                    fill="black"></path>
                </svg>
              </span>
              <span
                class="bullet bullet-dot bg-success h-6px w-6px position-absolute translate-middle top-0 start-50 animation-blink"></span>
            </div>
            <div class="menu menu-sub menu-sub-dropdown menu-column w-350px w-lg-375px" data-kt-menu="true">
              <div class="d-flex flex-column bgi-no-repeat rounded-top"
                style="background-image: url('/public/assets/images/pattern-1.jpg')">
                <h3 class="text-white fw-bold px-9 mt-10 mb-6">
                  Alerts
                  <span class="fs-8 opacity-75 ms-3 badge badge-light-info">24</span>
                </h3>
                <ul class="nav nav-line-tabs nav-line-tabs-2x nav-stretch fw-bold px-9">
                  <li class="nav-item">
                    <a class="nav-link text-white opacity-75 opacity-state-100 pb-4" data-bs-toggle="tab"
                      href="#kt_topbar_notifications_1">Notifications</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-white opacity-75 opacity-state-100 pb-4 active" data-bs-toggle="tab"
                      href="#kt_topbar_notifications_2">Updates</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-white opacity-75 opacity-state-100 pb-4" data-bs-toggle="tab"
                      href="#kt_topbar_notifications_3">Downloads</a>
                  </li>
                </ul>
              </div>
              <div class="tab-content">
                <div class="tab-pane fade" id="kt_topbar_notifications_1" role="tabpanel">
                  <div class="scroll-y mh-325px my-5 px-8">
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-bell me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <a href="javascript:;" class="fs-6 text-gray-800 text-hover-primary fw-bold">View
                            contact list</a>
                          <div class="text-gray-400 fs-7">
                            A contact list
                            <span class="fw-semibold text-gray-500">Employees List</span>
                            has been imported into
                            <span class="fw-semibold text-gray-500">Staff List</span>
                          </div>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">just now</span>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-bell me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <a href="#" class="fs-6 text-gray-800 text-hover-primary fw-bold">HR Confidential</a>
                          <div class="text-gray-400 fs-7">
                            A contact list
                            <span class="fw-semibold text-gray-500">Employees List</span>
                            has been imported into
                            <span class="fw-semibold text-gray-500">Staff List</span>
                          </div>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">2 hours</span>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-bell me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <a href="#" class="fs-6 text-gray-800 text-hover-primary fw-bold">Company HR</a>
                          <div class="text-gray-400 fs-7">
                            A contact list
                            <span class="fw-semibold text-gray-500">Employees List</span>
                            has been imported into
                            <span class="fw-semibold text-gray-500">Staff List</span>
                          </div>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">15 hours</span>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-bell me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <a href="#" class="fs-6 text-gray-800 text-hover-primary fw-bold">Project Redux</a>
                          <div class="text-gray-400 fs-7">
                            A contact list
                            <span class="fw-semibold text-gray-500">Employees List</span>
                            has been imported into
                            <span class="fw-semibold text-gray-500">Staff List</span>
                          </div>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">2 days</span>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-bell me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <a href="#" class="fs-6 text-gray-800 text-hover-primary fw-bold">Project Breafing</a>
                          <div class="text-gray-400 fs-7">
                            A contact list
                            <span class="fw-semibold text-gray-500">Employees List</span>
                            has been imported into
                            <span class="fw-semibold text-gray-500">Staff List</span>
                          </div>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">3 weeks</span>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-bell me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <a href="#" class="fs-6 text-gray-800 text-hover-primary fw-bold">Banner Assets</a>
                          <div class="text-gray-400 fs-7">
                            A contact list
                            <span class="fw-semibold text-gray-500">Employees List</span>
                            has been imported into
                            <span class="fw-semibold text-gray-500">Staff List</span>
                          </div>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">2 months</span>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-4">
                          <span class="symbol-label bg-light-primary">
                            <span class="svg-icon svg-icon-2 svg-icon-primary">
                              <i class="fa fa-bell me-0 text-primary fa-lg"></i>
                            </span>
                          </span>
                        </div>
                        <div class="mb-0 me-2">
                          <a href="#" class="fs-6 text-gray-800 text-hover-primary fw-bold">Icon Assets</a>
                          <div class="text-gray-400 fs-7">
                            A contact list
                            <span class="fw-semibold text-gray-500">Employees List</span>
                            has been imported into
                            <span class="fw-semibold text-gray-500">Staff List</span>
                          </div>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">8 months</span>
                    </div>
                  </div>
                  <div class="py-3 text-center border-top">
                    <a href="#" class="btn btn-color-gray-600 btn-active-color-primary">
                      View All
                      <span class="svg-icon svg-icon-5">
                        <i class="fa fa-arrow-right fs-8"></i>
                      </span>
                    </a>
                  </div>
                </div>
                <div class="tab-pane fade show active" id="kt_topbar_notifications_2" role="tabpanel">
                  <div class="d-flex flex-column px-9">
                    <div class="pt-10 pb-0">
                      <h3 class="text-dark text-center fw-bolder">
                        Update Mumara
                      </h3>
                      <div class="text-center text-gray-400 fw-bold pt-1">
                        Latest Version
                      </div>
                      <h3 class="text-center text-warning fw-semibold pt-1 text-decoration-line">
                        5.1.30
                      </h3>
                      <h1 class="text-center text-success fw-bold pt-1">
                        5.1.31
                      </h1>
                      <div class="text-center text-gray-400 fw-bold pt-1">
                        Feb 25, 2023
                      </div>
                      <div class="text-center mt-5">
                        <a href="javascript:;" class="btn btn-sm btn-primary px-6" data-bs-toggle="modal"
                          data-bs-target="#kt_modal_upgrade_plan">Update Now</a>
                      </div>
                    </div>
                    <div class="text-center px-4">
                      <img class="mw-100 mh-200px mt--20" alt="image" src="/public/assets/images/2.png" />
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade" id="kt_topbar_notifications_3" role="tabpanel">
                  <div class="scroll-y mh-325px my-5 px-8">
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center me-2">
                        <a href="javascript:;" download="download" data-bs-toggle="tooltip"
                          data-bs-placement="left" data-bs-original-title="Download Contact List">
                          <span class="w-70px badge badge-light-success me-4">
                            <i class="fa fa-cloud-download-alt text-success m-0 fa-lg"></i>
                          </span>
                        </a>
                        <div class="text-gray-800 fw-bold">
                          All Lists
                          <a href="javascript:;" download="download"
                            class="fw-mormal text-muted text-hover-primary text-link d-block">Download file</a>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">Just now</span>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center me-2">
                        <a href="javascript:;" download="download" data-bs-toggle="tooltip"
                          data-bs-placement="left" data-bs-original-title="Download Segment">
                          <span class="w-70px badge badge-light-success me-4">
                            <i class="fa fa-cloud-download-alt text-success m-0 fa-lg"></i>
                          </span>
                        </a>
                        <div class="text-gray-800 fw-bold">
                          Employee Segment
                          <a href="javascript:;" download="download"
                            class="fw-mormal text-muted text-hover-primary text-link d-block">Download file</a>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">15 minutes</span>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center me-2">
                        <a href="javascript:;" download="download" data-bs-toggle="tooltip"
                          data-bs-placement="left" data-bs-original-title="Download Segment">
                          <span class="w-70px badge badge-light-success me-4">
                            <i class="fa fa-cloud-download-alt text-success m-0 fa-lg"></i>
                          </span>
                        </a>
                        <div class="text-gray-800 fw-bold">
                          Independent List
                          <a href="javascript:;" download="download"
                            class="fw-mormal text-muted text-hover-primary text-link d-block">Download file</a>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">3 hours</span>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center me-2">
                        <a href="javascript:;" download="download" data-bs-toggle="tooltip"
                          data-bs-placement="left" data-bs-original-title="Download List">
                          <span class="w-70px badge badge-light-success me-4">
                            <i class="fa fa-cloud-download-alt text-success m-0 fa-lg"></i>
                          </span>
                        </a>
                        <div class="text-gray-800 fw-bold">
                          Employee List
                          <a href="javascript:;" download="download"
                            class="fw-mormal text-muted text-hover-primary text-link d-block">Download file</a>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">15 hours</span>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center me-2">
                        <a href="javascript:;" download="download" data-bs-toggle="tooltip"
                          data-bs-placement="left" data-bs-original-title="Download List">
                          <span class="w-70px badge badge-light-success me-4">
                            <i class="fa fa-cloud-download-alt text-success m-0 fa-lg"></i>
                          </span>
                        </a>
                        <div class="text-gray-800 fw-bold">
                          Subscribers List
                          <a href="javascript:;" download="download"
                            class="fw-mormal text-muted text-hover-primary text-link d-block">Download file</a>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">3 days</span>
                    </div>
                    <div class="d-flex flex-stack py-4">
                      <div class="d-flex align-items-center me-2">
                        <a href="javascript:;" download="download" data-bs-toggle="tooltip"
                          data-bs-placement="left" data-bs-original-title="Download Segment">
                          <span class="w-70px badge badge-light-success me-4">
                            <i class="fa fa-cloud-download-alt text-success m-0 fa-lg"></i>
                          </span>
                        </a>
                        <div class="text-gray-800 fw-bold">
                          All Lists Segments
                          <a href="javascript:;" download="download"
                            class="fw-mormal text-muted text-hover-primary text-link d-block">Download file</a>
                        </div>
                      </div>
                      <span class="badge badge-light fs-8">2 months</span>
                    </div>
                  </div>
                  <div class="py-3 text-center border-top">
                    <a href="#" class="btn btn-color-gray-600 btn-active-color-primary">
                      View All
                      <span class="svg-icon svg-icon-5">
                        <i class="fa fa-arrow-right fs-8"></i>
                      </span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="d-flex align-items-center ms-1 ms-lg-3">
            <div
              class="btn btn-icon btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px"
              data-kt-menu-trigger="click" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
              <span class="svg-icon svg-icon-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
                  class="kt-svg-icon">
                  <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <rect id="bound" x="0" y="0" width="24" height="24" />
                    <rect id="Rectangle-7" fill="#000000" opacity="0.3" x="4" y="4" width="4" height="4" rx="1" />
                    <path
                      d="M5,10 L7,10 C7.55228475,10 8,10.4477153 8,11 L8,13 C8,13.5522847 7.55228475,14 7,14 L5,14 C4.44771525,14 4,13.5522847 4,13 L4,11 C4,10.4477153 4.44771525,10 5,10 Z M11,4 L13,4 C13.5522847,4 14,4.44771525 14,5 L14,7 C14,7.55228475 13.5522847,8 13,8 L11,8 C10.4477153,8 10,7.55228475 10,7 L10,5 C10,4.44771525 10.4477153,4 11,4 Z M11,10 L13,10 C13.5522847,10 14,10.4477153 14,11 L14,13 C14,13.5522847 13.5522847,14 13,14 L11,14 C10.4477153,14 10,13.5522847 10,13 L10,11 C10,10.4477153 10.4477153,10 11,10 Z M17,4 L19,4 C19.5522847,4 20,4.44771525 20,5 L20,7 C20,7.55228475 19.5522847,8 19,8 L17,8 C16.4477153,8 16,7.55228475 16,7 L16,5 C16,4.44771525 16.4477153,4 17,4 Z M17,10 L19,10 C19.5522847,10 20,10.4477153 20,11 L20,13 C20,13.5522847 19.5522847,14 19,14 L17,14 C16.4477153,14 16,13.5522847 16,13 L16,11 C16,10.4477153 16.4477153,10 17,10 Z M5,16 L7,16 C7.55228475,16 8,16.4477153 8,17 L8,19 C8,19.5522847 7.55228475,20 7,20 L5,20 C4.44771525,20 4,19.5522847 4,19 L4,17 C4,16.4477153 4.44771525,16 5,16 Z M11,16 L13,16 C13.5522847,16 14,16.4477153 14,17 L14,19 C14,19.5522847 13.5522847,20 13,20 L11,20 C10.4477153,20 10,19.5522847 10,19 L10,17 C10,16.4477153 10.4477153,16 11,16 Z M17,16 L19,16 C19.5522847,16 20,16.4477153 20,17 L20,19 C20,19.5522847 19.5522847,20 19,20 L17,20 C16.4477153,20 16,19.5522847 16,19 L16,17 C16,16.4477153 16.4477153,16 17,16 Z"
                      id="Combined-Shape" fill="#000000" />
                  </g>
                </svg>
              </span>
            </div>
            <div class="menu menu-sub menu-sub-dropdown menu-column w-100 w-sm-350px" data-kt-menu="true">
              <div class="card">
                <div class="card-header">
                  <div class="card-title">My Apps</div>
                </div>
                <div class="card-body px-4">
                  <div class="mh-450px scroll-y hidden-x">
                    <div class="row g-2">
                      <div class="col-4">
                        <a href="#"
                          class="d-flex flex-column flex-center text-center text-gray-800 text-hover-primary bg-hover-light rounded py-4 px-3 mb-3">
                          <img src="/public/assets/images/one.png" class="w-25px h-25px mb-2" alt="" />
                          <span class="fw-semibold">Mumara</span>
                        </a>
                      </div>
                      <div class="col-4">
                        <a href="#"
                          class="d-flex flex-column flex-center text-center text-gray-800 text-hover-primary bg-hover-light rounded py-4 px-3 mb-3">
                          <img src="/public/assets/images/accounts.png" class="w-25px h-25px mb-2" alt="" />
                          <span class="fw-semibold">Accounts</span>
                        </a>
                      </div>
                      <div class="col-4">
                        <a href="#"
                          class="d-flex flex-column flex-center text-center text-gray-800 text-hover-primary bg-hover-light rounded py-4 px-3 mb-3">
                          <img src="/public/assets/images/thumb.jpg" class="w-25px h-25px mb-2" alt="" />
                          <span class="fw-semibold">Atica</span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="d-flex align-items-center ms-1 ms-lg-3">
            <div
              class="btn btn-icon btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px"
              data-kt-menu-trigger="click" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
              <span class="svg-icon svg-icon-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <rect x="2" y="2" width="9" height="9" rx="2" fill="black"></rect>
                  <rect opacity="0.3" x="13" y="2" width="9" height="9" rx="2" fill="black"></rect>
                  <rect opacity="0.3" x="13" y="13" width="9" height="9" rx="2" fill="black"></rect>
                  <rect opacity="0.3" x="2" y="13" width="9" height="9" rx="2" fill="black"></rect>
                </svg>
              </span>
            </div>
            <div class="menu menu-sub menu-sub-dropdown menu-column w-250px w-lg-325px quick-links"
              data-kt-menu="true">
              <div class="d-flex flex-column flex-center bgi-no-repeat rounded-top px-9 py-10" style="
                    background-image: url('/public/assets/images/pattern-1.jpg');
                    background-position: center;
                  ">
                <h3 class="text-white fw-bold">Quick Links</h3>
              </div>
              <div class="row g-0">
                <div class="col-6">
                  <a href="https://help.mumara.com/hc/en-us" target="_blank"
                    class="d-flex flex-column flex-center h-100 px-1 py-6 bg-hover-light border-end border-bottom">
                    <span class="svg-icon svg-icon-3x svg-icon-primary mb-2">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
                        version="1.1" class="kt-svg-icon">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                          <rect id="bound" x="0" y="0" width="24" height="24" />
                          <path
                            d="M13.6855025,18.7082217 C15.9113859,17.8189707 18.682885,17.2495635 22,17 C22,16.9325178 22,13.1012863 22,5.50630526 L21.9999762,5.50630526 C21.9999762,5.23017604 21.7761292,5.00632908 21.5,5.00632908 C21.4957817,5.00632908 21.4915635,5.00638247 21.4873465,5.00648922 C18.658231,5.07811173 15.8291155,5.74261533 13,7 C13,7.04449645 13,10.79246 13,18.2438906 L12.9999854,18.2438906 C12.9999854,18.520041 13.2238496,18.7439052 13.5,18.7439052 C13.5635398,18.7439052 13.6264972,18.7317946 13.6855025,18.7082217 Z"
                            id="Combined-Shape" fill="#000000" />
                          <path
                            d="M10.3144829,18.7082217 C8.08859955,17.8189707 5.31710038,17.2495635 1.99998542,17 C1.99998542,16.9325178 1.99998542,13.1012863 1.99998542,5.50630526 L2.00000925,5.50630526 C2.00000925,5.23017604 2.22385621,5.00632908 2.49998542,5.00632908 C2.50420375,5.00632908 2.5084219,5.00638247 2.51263888,5.00648922 C5.34175439,5.07811173 8.17086991,5.74261533 10.9999854,7 C10.9999854,7.04449645 10.9999854,10.79246 10.9999854,18.2438906 L11,18.2438906 C11,18.520041 10.7761358,18.7439052 10.4999854,18.7439052 C10.4364457,18.7439052 10.3734882,18.7317946 10.3144829,18.7082217 Z"
                            id="Path-41-Copy" fill="#000000" opacity="0.3" />
                        </g>
                      </svg>
                    </span>
                    <span class="fs-6 fw-bold text-gray-800 mb-0">
                      Knowledge base
                    </span>
                    <span class="fs-7 text-gray-400">Knowledge base</span>
                  </a>
                </div>
                <div class="col-6">
                  <a href="https://community.mumara.com/" target="_blank"
                    class="d-flex flex-column flex-center h-100 px-1 py-6 bg-hover-light border-end border-bottom">
                    <span class="svg-icon svg-icon-3x svg-icon-primary mb-2">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
                        version="1.1" class="kt-svg-icon">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                          <rect id="bound" x="0" y="0" width="24" height="24" />
                          <polygon id="Path-75" fill="#000000" opacity="0.3" points="5 15 3 21.5 9.5 19.5" />
                          <path
                            d="M13.5,21 C8.25329488,21 4,16.7467051 4,11.5 C4,6.25329488 8.25329488,2 13.5,2 C18.7467051,2 23,6.25329488 23,11.5 C23,16.7467051 18.7467051,21 13.5,21 Z M8.5,13 C9.32842712,13 10,12.3284271 10,11.5 C10,10.6715729 9.32842712,10 8.5,10 C7.67157288,10 7,10.6715729 7,11.5 C7,12.3284271 7.67157288,13 8.5,13 Z M13.5,13 C14.3284271,13 15,12.3284271 15,11.5 C15,10.6715729 14.3284271,10 13.5,10 C12.6715729,10 12,10.6715729 12,11.5 C12,12.3284271 12.6715729,13 13.5,13 Z M18.5,13 C19.3284271,13 20,12.3284271 20,11.5 C20,10.6715729 19.3284271,10 18.5,10 C17.6715729,10 17,10.6715729 17,11.5 C17,12.3284271 17.6715729,13 18.5,13 Z"
                            id="Combined-Shape" fill="#000000" />
                        </g>
                      </svg>
                    </span>
                    <span class="fs-6 fw-bold text-gray-800 mb-0">Community Support</span>
                    <span class="fs-7 text-gray-400">Community Support</span>
                  </a>
                </div>
                <div class="col-6">
                  <a href="https://community.mumara.com/forums/feature-request.14/" target="_blank"
                    class="d-flex flex-column flex-center h-100 px-1 py-6 bg-hover-light border-end border-bottom">
                    <span class="svg-icon svg-icon-3x svg-icon-primary mb-2">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
                        version="1.1" class="kt-svg-icon">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                          <rect id="bound" x="0" y="0" width="24" height="24" />
                          <path
                            d="M14,13.381038 L14,3.47213595 L7.99460483,15.4829263 L14,13.381038 Z M4.88230018,17.2353996 L13.2844582,0.431083506 C13.4820496,0.0359007077 13.9625881,-0.12427877 14.3577709,0.0733126292 C14.5125928,0.15072359 14.6381308,0.276261584 14.7155418,0.431083506 L23.1176998,17.2353996 C23.3152912,17.6305824 23.1551117,18.1111209 22.7599289,18.3087123 C22.5664522,18.4054506 22.3420471,18.4197165 22.1378777,18.3482572 L14,15.5 L5.86212227,18.3482572 C5.44509941,18.4942152 4.98871325,18.2744737 4.84275525,17.8574509 C4.77129597,17.6532815 4.78556182,17.4288764 4.88230018,17.2353996 Z"
                            id="Path-99" fill="#000000" fill-rule="nonzero"
                            transform="translate(14.000087, 9.191034) rotate(-315.000000) translate(-14.000087, -9.191034) " />
                        </g>
                      </svg>
                    </span>
                    <span class="fs-6 fw-bold text-gray-800 mb-0">Feature Request</span>
                    <span class="fs-7 text-gray-400">Feature Request</span>
                  </a>
                </div>
                <div class="col-6">
                  <a href="https://community.mumara.com/forums/bug-reporting.15/" target="_blank"
                    class="d-flex flex-column flex-center h-100 px-1 py-6 bg-hover-light border-end border-bottom">
                    <span class="svg-icon svg-icon-3x svg-icon-primary mb-2">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
                        version="1.1" class="kt-svg-icon">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                          <rect id="bound" x="0" y="0" width="24" height="24" />
                          <path
                            d="M8,17.9148182 L8,5.96685884 C8,5.56391781 8.16211443,5.17792052 8.44982609,4.89581508 L10.965708,2.42895648 C11.5426798,1.86322723 12.4640974,1.85620921 13.0496196,2.41308426 L15.5337377,4.77566479 C15.8314604,5.0588212 16,5.45170806 16,5.86258077 L16,17.9148182 C16,18.7432453 15.3284271,19.4148182 14.5,19.4148182 L9.5,19.4148182 C8.67157288,19.4148182 8,18.7432453 8,17.9148182 Z"
                            id="Path-11" fill="#000000" fill-rule="nonzero"
                            transform="translate(12.000000, 10.707409) rotate(-135.000000) translate(-12.000000, -10.707409) " />
                          <rect id="Rectangle" fill="#000000" opacity="0.3" x="5" y="20" width="15" height="2"
                            rx="1" />
                        </g>
                      </svg>
                    </span>
                    <span class="fs-6 fw-bold text-gray-800 mb-0">Report a Bug</span>
                    <span class="fs-7 text-gray-400">Report a Bug</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="d-flex align-items-center ms-1 ms-lg-3" id="kt_header_user_menu_toggle">
            <div class="cursor-pointer symbol symbol-30px symbol-md-40px show menu-dropdown"
              data-kt-menu-trigger="click" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
              <img src="/public/assets/images/blank.png" alt="user" />
            </div>
            <div
              class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-275px"
              data-kt-menu="true" style="
                  z-index: 105;
                  position: fixed;
                  inset: 0px 0px auto auto;
                  margin: 0px;
                  transform: translate(-30px, 65px);
                " data-popper-placement="bottom-end">
              <div class="menu-item px-3">
                <div class="menu-content d-flex align-items-center px-3">
                  <div class="symbol symbol-50px me-5">
                    <img alt="Logo" src="/public/assets/images/blank.png" />
                  </div>
                  <div class="d-flex flex-column">
                    <div class="fw-bolder d-flex align-items-center fs-5">
                      Wasif Ahmed
                    </div>
                    <a href="#" class="fw-bold text-muted text-hover-primary fs-7">admin@mumara.com</a>
                  </div>
                </div>
              </div>
              <div class="separator my-2"></div>
              <div class="menu-item">
                <a href="javascript:;" class="menu-link px-5" data-bs-toggle="tooltip" data-bs-placement="left"
                  data-bs-original-title="View or update your profile information">
                  <i class="fa fa-user-circle"></i> My Profile
                </a>
              </div>
              <div class="menu-item">
                <a href="javascript:;" class="menu-link px-5" data-bs-toggle="tooltip" data-bs-placement="left"
                  data-bs-original-title="Check account security or change password">
                  <i class="fa fa-shield-alt"></i>
                  Security
                </a>
              </div>
              <div class="menu-item">
                <a href="javascript:;" class="menu-link px-5" data-bs-toggle="tooltip" data-bs-placement="left"
                  data-bs-original-title="Learn about your current plan">
                  <i class="fa fa-dollar-sign"></i>
                  Subscription
                </a>
              </div>
              <div class="menu-item">
                <a href="javascript:;" class="menu-link px-5" data-bs-toggle="tooltip" data-bs-placement="left"
                  data-bs-original-title="Go to your billing area">
                  <i class="fa fa-file-invoice"></i>
                  Billing
                </a>
              </div>
              <div class="menu-item">
                <a href="javascript:;" class="menu-link px-5" data-bs-toggle="tooltip" data-bs-placement="left"
                  data-bs-original-title="Control the notifications that you want to receive">
                  <i class="fa fa-envelope"></i>
                  Preferences
                </a>
              </div>
              <div class="separator my-2"></div>
              <div class="menu-item">
                <a href="/logout" class="menu-link px-5">
                  <i class="fa fa-power-off"></i>
                  Logout
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div><?php /**PATH D:\Wamp\www\Mumara-WhatsApp\resources\views/partials/header.blade.php ENDPATH**/ ?>