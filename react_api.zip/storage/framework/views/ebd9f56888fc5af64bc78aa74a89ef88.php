<?php $__env->startSection('style'); ?>
<link href="/public/assets/css/toastr.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<!--<script src="/public/assets/js/jquery.js"type="text/javascript"></script>-->
<script src="/public/assets/js/select2.full.min.js"></script>
<script src="/public/assets/js/select2.js"></script>
<script src="/public/assets/js/toastr.min.js"></script>
<script src="/public/assets/js/jquery.validate.min.js"type="text/javascript"></script>

<script>
    $(document).ready(function () {
        $("#saveBtn").attr('disabled',false);
        $("#frmUsers").validate({
            rules: {
                role_id: "required",
                first_name: "required",
                last_name: "required",
                email:  {
                    required: true,
                    email: true
                },
                mobile_no: "required",
                country: "required",
                time_zone: "required",
                status: "required",
                
            },
            messages: {
                role_id: "<?php echo e(trans('users.add_user.validation_message.role_id')); ?>",
                first_name: "<?php echo e(trans('users.add_user.validation_message.first_name')); ?>",
                last_name: "<?php echo e(trans('users.add_user.validation_message.last_name')); ?>",
                email: "<?php echo e(trans('users.add_user.validation_message.email')); ?>",
                mobile_no: "<?php echo e(trans('users.add_user.validation_message.mobile_no')); ?>",
                country: "<?php echo e(trans('users.add_user.validation_message.country')); ?>",
                time_zone: "<?php echo e(trans('users.add_user.validation_message.time_zone')); ?>",
                status: "<?php echo e(trans('users.add_user.validation_message.status')); ?>",
            },
            submitHandler: function (form) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('save.user')); ?>",
                    data: new FormData($("#frmUsers")[0]),
                    contentType: false, // The content type used when sending data to the server.
                    cache: false, // To unable request pages to be cached
                    processData: false, // To send DOMDocument or non processed data file it is set to false
                    success: function (data) {
                        if (data.status == "success") {
                            var msgClass = 'success';
                        } else {
                            var msgClass = 'error';
                        }
                        Command: toastr[msgClass](data.message + '...');
                        if (data.status == "success") {
                            window.setTimeout(function () {
                              window.location.href = "<?php echo e(route('view.users')); ?>";
                          }, 3000);  
                        }
                        
                    }
                });
            }
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-5 g-xl-10">
    <div class="col-xl-12 col-md-6 mb-md-5">
        <?php echo $__env->make('partials.title_description', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div id="kt_app_content_container" class="app-container container-xxl">
        <div class="d-flex flex-column flex-lg-row">
            <div class="flex-lg-row-fluid ms-lg-15">
                <ul class="nav nav-custom nav-tabs nav-line-tabs nav-line-tabs-2x border-0 fs-4 fw-semibold mb-8" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link text-active-primary pb-4 active" data-bs-toggle="tab" href="#kt_user_view_overview_tab" aria-selected="true" role="tab">Overview</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link text-active-primary pb-4" data-kt-countup-tabs="true" data-bs-toggle="tab" href="#kt_user_view_overview_security" data-kt-initialized="1" aria-selected="false" tabindex="-1" role="tab">Security</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="kt_user_view_overview_tab" role="tabpanel">
                        <div class="card">
                            <div class="card-body">
                                <form class="form" action="#" id="frmUsers" name="frmUsers" method="post" >
                                    <input type="hidden" name="id" id="id" value="<?php echo e($id); ?>" />
                                    <input type="hidden" id="_token" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <div class="modal-body py-5 px-lg-5">
                                        <div class="d-flex flex-column">
                                            <h3 class="rotate collapsible mb-7" data-bs-toggle="collapse" href="#kt_modal_update_user_user_info" role="button" aria-expanded="false" aria-controls="kt_modal_update_user_user_info">User Information <span class="ms-2 rotate-180">
                                                    <span class="svg-icon svg-icon-3">
                                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                                                        </svg>
                                                    </span>
                                                </span>
                                            </h3>
                                            <div id="kt_modal_update_user_user_info" class="collapse show">
                                                <div class="mb-7">
                                                    <label class="fs-6 fw-semibold mb-2">
                                                        <span>Update Avatar</span>
                                                        <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Allowed file types: png, jpg, jpeg." data-bs-original-title="Allowed file types: png, jpg, jpeg." data-kt-initialized="1"></i>
                                                    </label>
                                                    <div class="mt-1">
                                                        <style>
                                                            .image-input-placeholder {
                                                                background-image: url('/public/assets/images/blank.png');
                                                            }

                                                            [data-theme="dark"] .image-input-placeholder {
                                                                background-image: url('/public/assets/images/blank.png');
                                                            }
                                                        </style>
                                                        <div class="image-input image-input-outline image-input-placeholder" data-kt-image-input="true">
                                                            <div class="image-input-wrapper w-125px h-125px" style="background-image: url(/public/assets/images/blank.png)"></div>
                                                            <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="change" data-bs-toggle="tooltip" aria-label="Change avatar" data-bs-original-title="Change avatar" data-kt-initialized="1">
                                                                <i class="bi bi-pencil-fill fs-7"></i>
                                                                <input type="file" name="avatar" id="avatar" accept=".png, .jpg, .jpeg">
                                                                    <input type="hidden" name="avatar_remove">
                                                                        </label>
                                                                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="cancel" data-bs-toggle="tooltip" aria-label="Cancel avatar" data-bs-original-title="Cancel avatar" data-kt-initialized="1">
                                                                            <i class="bi bi-x fs-2"></i>
                                                                        </span>
                                                                        <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="remove" data-bs-toggle="tooltip" aria-label="Remove avatar" data-bs-original-title="Remove avatar" data-kt-initialized="1">
                                                                            <i class="bi bi-x fs-2"></i>
                                                                        </span>
                                                                        </div>
                                                                        </div>
                                                                        </div>

                                                                        <div class="d-flex flex-column mb-7 fv-row">
                                                                            <label class="fs-6 fw-semibold mb-2">
                                                                                <span>Role</span>
                                                                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Status" data-bs-original-title="Status" data-kt-initialized="1"></i>
                                                                            </label>
                                                                            <select class="form-select form-select-solid form-select-lg" data-control="select2" name="role_id" id="role_id" aria-label="Select a Role" data-placeholder="Select a Role...">

                                                                                <option value="" data-select2-id="select2-data-30-4o0c">Select a Role...</option>
                                                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option <?php if(isset($userRow['role_id']) && $userRow['role_id']==$role['id']): ?> selected="" <?php endif; ?>   value="<?php echo e($role['id']); ?>"><?php echo e($role['role_name']); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                        <div class="fv-row mb-7">
                                                                            <label class="fs-6 fw-semibold mb-2">First name</label>
                                                                            <input type="text" class="form-control form-control-solid" placeholder="" name="first_name" id="first_name" value="<?php echo e((isset($userRow['first_name'])?$userRow['first_name'] :"")); ?>">
                                                                        </div>
                                                                        <div class="fv-row mb-7">
                                                                            <label class="fs-6 fw-semibold mb-2">Last name</label>
                                                                            <input type="text" class="form-control form-control-solid" placeholder="" name="last_name" id="last_name" value="<?php echo e((isset($userRow['last_name'])?$userRow['last_name'] :"")); ?>">
                                                                        </div>
                                                                        <div class="fv-row mb-7">
                                                                            <label class="fs-6 fw-semibold mb-2">
                                                                                <span>Email</span>
                                                                                <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Email address must be active" data-bs-original-title="Email address must be active" data-kt-initialized="1"></i>
                                                                            </label>
                                                                            <input type="email" class="form-control form-control-solid" placeholder="email" name="email" id="email" value="<?php echo e((isset($userRow['email'])?$userRow['email'] :"")); ?>">
                                                                        </div>
                                                                        <div class="fv-row mb-7">
                                                                            <label class="fs-6 fw-semibold mb-2">Mobile No</label>
                                                                            <input type="text" class="form-control form-control-solid" placeholder="Mobile NO" name="mobile_no" id="mobile_no" value="<?php echo e((isset($userRow['mobile_no'])?$userRow['mobile_no'] :"")); ?>">
                                                                        </div>
                                                                        <div class="fv-row mb-7">
                                                                            <label class="fs-6 fw-semibold mb-2">phone</label>
                                                                            <input type="text" class="form-control form-control-solid" placeholder="Phone" name="phone" id="phone" value="<?php echo e((isset($userRow['phone'])?$userRow['phone'] :"")); ?>">
                                                                        </div>

                                                                        </div>
                                                                        <h3 class="rotate collapsible mb-7" data-bs-toggle="collapse" href="#kt_modal_update_user_address" role="button" aria-expanded="false" aria-controls="kt_modal_update_user_address">Address Details <span class="ms-2 rotate-180">
                                                                                <span class="svg-icon svg-icon-3">
                                                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                        <path d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z" fill="currentColor"></path>
                                                                                    </svg>
                                                                                </span>
                                                                            </span>
                                                                        </h3>
                                                                        <div id="kt_modal_update_user_address" class="collapse show">
                                                                            <div class="d-flex flex-column mb-7 fv-row">
                                                                                <label class="fs-6 fw-semibold mb-2">Address</label>
                                                                                <input class="form-control form-control-solid" placeholder="" name="address" id="address" value="<?php echo e((isset($userRow['address'])?$userRow['address'] :"")); ?>">
                                                                            </div>
                                                                            <div class="d-flex flex-column mb-7 fv-row">
                                                                                <label class="fs-6 fw-semibold mb-2">City</label>
                                                                                <input class="form-control form-control-solid" placeholder="" name="city" id="city" value="<?php echo e((isset($userRow['city'])?$userRow['city'] :"")); ?>">
                                                                            </div>
                                                                            <div class="row g-9 mb-7">
                                                                                <div class="col-md-6 fv-row">
                                                                                    <label class="fs-6 fw-semibold mb-2">State / Province</label>
                                                                                    <input class="form-control form-control-solid" placeholder="" name="state" id="state" value="<?php echo e((isset($userRow['state'])?$userRow['state'] :"")); ?>">
                                                                                </div>
                                                                                <div class="col-md-6 fv-row">
                                                                                    <label class="fs-6 fw-semibold mb-2">Post Code</label>
                                                                                    <input class="form-control form-control-solid" placeholder="" name="zip" value="<?php echo e((isset($userRow['zip'])?$userRow['zip'] :"")); ?>" id="zip">
                                                                                </div>
                                                                            </div>
                                                                            <div class="d-flex flex-column mb-7 fv-row">
                                                                                <label class="fs-6 fw-semibold mb-2">
                                                                                    <span>Country</span>
                                                                                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Country of origination" data-bs-original-title="Country of origination" data-kt-initialized="1"></i>
                                                                                </label>
                                                                                <select class="form-select form-select-solid form-select-lg" data-control="select2" name="country" id="country" aria-label="Select a Country" data-placeholder="Select a Country...">
                                                                                    <option value="" data-select2-id="select2-data-30-4o0c">Select a Country...</option>
                                                                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option <?php if(isset($userRow['country']) && $userRow['country']== $country['country_code']): ?> selected="" <?php endif; ?> value="<?php echo e($country['country_code']); ?>"><?php echo e($country['country_name']); ?></option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            </div>
                                                                            <div class="d-flex flex-column mb-7 fv-row">
                                                                                <label class="fs-6 fw-semibold mb-2">
                                                                                    <span>Time Zone</span>
                                                                                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Country of origination" data-bs-original-title="Country of origination" data-kt-initialized="1"></i>
                                                                                </label>
                                                                                <select class="form-select form-select-solid form-select-lg" data-control="select2" name="time_zone" id="time_zone" aria-label="Select a Country" data-placeholder="Select a Country...">
                                                                                    <option value=""><?php echo e(trans('file.create_user.label.time_zone_option')); ?></option>
                                                                                    <option value="-12:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-12:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-12')); ?></option>
                                                                                    <option value="-11:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-11:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-11')); ?></option>
                                                                                    <option value="-10:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-10:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-10')); ?></option>
                                                                                    <option value="-09:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-09:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-9')); ?></option>
                                                                                    <option value="-08:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-08:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-8')); ?></option>
                                                                                    <option value="-07:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-07:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-7')); ?></option>
                                                                                    <option value="-06:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-06:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-6')); ?></option>
                                                                                    <option value="-05:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-05:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-5')); ?></option>
                                                                                    <option value="-04:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-04:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-4')); ?></option>
                                                                                    <option value="-03:30" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-03:30'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-330')); ?></option>
                                                                                    <option value="-03:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-03:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-3')); ?></option>
                                                                                    <option value="-02:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-02:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-2')); ?></option>
                                                                                    <option value="-01:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='-01:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT-1')); ?></option>
                                                                                    <option value="+00:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+00:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT')); ?></option>
                                                                                    <option value="+01:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+01:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+1')); ?></option>
                                                                                    <option value="+02:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+02:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+2')); ?></option>
                                                                                    <option value="+03:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+03:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+3')); ?></option>
                                                                                    <option value="+03:30" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+03:30'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+330')); ?></option>
                                                                                    <option value="+04:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+04:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+4')); ?></option>
                                                                                    <option value="+04:30" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+04:30'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+430')); ?></option>
                                                                                    <option value="+05:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+05:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+5')); ?></option>
                                                                                    <option value="+05:30" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+05:30'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+530')); ?></option>
                                                                                    <option value="+06:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+06:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+6')); ?></option>
                                                                                    <option value="+07:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+07:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+7')); ?></option>
                                                                                    <option value="+08:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+08:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+8')); ?></option>
                                                                                    <option value="+09:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+09:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+9')); ?></option>
                                                                                    <option value="+09:30" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+09:30'): ?> selected="" <?php endif; ?> >(GMT +9:30) Adelaide, <?php echo e(trans('file.GMT+930')); ?></option>
                                                                                    <option value="+10:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+10:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+10')); ?></option>
                                                                                    <option value="+11:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+11:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+11')); ?></option>
                                                                                    <option value="+12:00" <?php if(isset($userRow['time_zone']) && $userRow['time_zone']=='+12:00'): ?> selected="" <?php endif; ?> ><?php echo e(trans('file.GMT+12')); ?></option>

                                                                                </select>
                                                                            </div>

<!--                                                                            <div class="row g-9 mb-7">
                                                                                <div class="col-md-6 fv-row">
                                                                                    <label class="fs-6 fw-semibold mb-2">WHMCS Account ID</label>
                                                                                    <input type="number" class="form-control form-control-solid" placeholder="WHMCS Account ID" name="whmcs_id" id="whmcs_id" value="">
                                                                                </div>
                                                                                <div class="col-md-6 fv-row">
                                                                                    <label class="fs-6 fw-semibold mb-2">WHMCS PID</label>
                                                                                    <input class="form-control form-control-solid" placeholder="" name="whmcs_pid" value="" id="whmcs_pid">
                                                                                </div>
                                                                            </div>
                                                                            <div class="row g-9 mb-7">
                                                                                <div class="col-md-6 fv-row">
                                                                                    <label class="fs-6 fw-semibold mb-2">WHMCS Service ID</label>
                                                                                    <input type="number" class="form-control form-control-solid" placeholder="WHMCS Service ID" name="whmcs_service_id" id="whmcs_service_id" value="">
                                                                                </div>
                                                                                <div class="col-md-6 fv-row">
                                                                                    <label class="fs-6 fw-semibold mb-2">WHMCS Package ID</label>
                                                                                    <input class="form-control form-control-solid" placeholder="WHMCS Package ID" name="whmcs_package_id" value="" id="whmcs_package_id">
                                                                                </div>
                                                                            </div>-->
                                                                            <div class="d-flex flex-column mb-7 fv-row">
                                                                                <label class="fs-6 fw-semibold mb-2">
                                                                                    <span>Status</span>
                                                                                    <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" aria-label="Status" data-bs-original-title="Status" data-kt-initialized="1"></i>
                                                                                </label>
                                                                                <select class="form-select form-select-solid form-select-lg" data-control="select2" name="status" id="status" aria-label="Select a Status" data-placeholder="Select a Status...">
                                                                                    <option  value="" data-select2-id="select2-data-30-4o0c">Select a Status...</option>
                                                                                    <option <?php if(isset($userRow['status']) && $userRow['status']=='pending_approval'): ?> selelected <?php endif; ?> value="pending_approval">Pending Approval</option>
                                                                                    <option <?php if(isset($userRow['status']) && $userRow['status']=='active'): ?> selelected <?php endif; ?> value="active">Active</option>
                                                                                    <option <?php if(isset($userRow['status']) && $userRow['status']=='suspended'): ?> selelected <?php endif; ?> value="suspended">Suspended</option>
                                                                                    <option <?php if(isset($userRow['status']) && $userRow['status']=='banned'): ?> selelected <?php endif; ?> value="banned">Banned</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        </div>
                                                                        </div>
                                                                        <div class="modal-footer flex-center pb-0">
                                                                            <button type="reset" class="btn btn-light me-3" data-kt-users-modal-action="cancel">Discard</button>
                                                                            <button type="submit" class="btn btn-primary" data-kt-users-modal-action="submit">
                                                                                <span class="indicator-label">Submit</span>
                                                                                <span class="indicator-progress">Please wait... <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                                                                                </span>
                                                                            </button>
                                                                        </div>
                                                                        </form>
                                                                        </div>
                                                                        </div>
                                                                        </div>
                                                                        <div class="tab-pane fade" id="kt_user_view_overview_security" role="tabpanel">
                                                                            <div class="card pt-4 mb-6 mb-xl-9">
                                                                                <div class="card-header border-0">
                                                                                    <div class="card-title">
                                                                                        <h3>Profile</h3>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="card-body pt-0 pb-5">
                                                                                    <div class="table-responsive">
                                                                                        <table class="table align-middle table-row-dashed gy-5" id="kt_table_users_login_session">
                                                                                            <tbody class="fs-6 fw-semibold text-gray-600">
                                                                                                <tr>
                                                                                                    <td>Email</td>
                                                                                                    <td>smith@kpmg.com</td>
                                                                                                    <td class="text-end"></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td>Password</td>
                                                                                                    <td>******</td>
                                                                                                    <td class="text-end">
                                                                                                        <button type="button" class="btn btn-icon btn-active-light-primary w-30px h-30px ms-auto" data-bs-toggle="modal" data-bs-target="#kt_modal_update_password">
                                                                                                            <span class="svg-icon svg-icon-3">
                                                                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                                                                                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                                                                                                </svg>
                                                                                                            </span>
                                                                                                        </button>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        </div>
                                                                        </div>
                                                                        </div>
                                                                        <div class="modal fade" id="kt_modal_update_password" tabindex="-1" aria-hidden="true">
                                                                            <div class="modal-dialog modal-dialog-centered mw-650px">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header">
                                                                                        <h2 class="fw-bold">Update Password</h2>
                                                                                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-kt-users-modal-action="close">
                                                                                            <span class="svg-icon svg-icon-1">
                                                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                                                                                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                                                                                                </svg>
                                                                                            </span>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                                                                                        <form id="kt_modal_update_password_form" class="form fv-plugins-bootstrap5 fv-plugins-framework" action="#">
                                                                                            <div class="fv-row mb-10 fv-plugins-icon-container">
                                                                                                <label class="required form-label fs-6 mb-2">Current Password</label>
                                                                                                <input class="form-control form-control-lg form-control-solid" type="password" placeholder="" name="current_password" autocomplete="off">
                                                                                                    <div class="fv-plugins-message-container invalid-feedback"></div><div class="fv-plugins-message-container invalid-feedback"></div></div>
                                                                                            <div class="mb-10 fv-row fv-plugins-icon-container" data-kt-password-meter="true">
                                                                                                <div class="mb-1">
                                                                                                    <label class="form-label fw-semibold fs-6 mb-2">New Password</label>
                                                                                                    <div class="position-relative mb-3">
                                                                                                        <input class="form-control form-control-lg form-control-solid" type="password" placeholder="" name="new_password" autocomplete="off">
                                                                                                            <span class="btn btn-sm btn-icon position-absolute translate-middle top-50 end-0 me-n2" data-kt-password-meter-control="visibility">
                                                                                                                <i class="bi bi-eye-slash fs-2"></i>
                                                                                                                <i class="bi bi-eye fs-2 d-none"></i>
                                                                                                            </span>
                                                                                                    </div>
                                                                                                    <div class="d-flex align-items-center mb-3" data-kt-password-meter-control="highlight">
                                                                                                        <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"></div>
                                                                                                        <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"></div>
                                                                                                        <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px me-2"></div>
                                                                                                        <div class="flex-grow-1 bg-secondary bg-active-success rounded h-5px"></div>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="text-muted">Use 8 or more characters with a mix of letters, numbers &amp; symbols.</div>
                                                                                                <div class="fv-plugins-message-container invalid-feedback"></div><div class="fv-plugins-message-container invalid-feedback"></div></div>
                                                                                            <div class="fv-row mb-10 fv-plugins-icon-container">
                                                                                                <label class="form-label fw-semibold fs-6 mb-2">Confirm New Password</label>
                                                                                                <input class="form-control form-control-lg form-control-solid" type="password" placeholder="" name="confirm_password" autocomplete="off">
                                                                                                    <div class="fv-plugins-message-container invalid-feedback"></div><div class="fv-plugins-message-container invalid-feedback"></div></div>
                                                                                            <div class="text-center pt-15">
                                                                                                <button type="reset" class="btn btn-light me-3" data-kt-users-modal-action="cancel">Discard</button>
                                                                                                <button type="submit" class="btn btn-primary" data-kt-users-modal-action="submit">
                                                                                                    <span class="indicator-label">Submit</span>
                                                                                                    <span class="indicator-progress">Please wait...
                                                                                                        <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                                                                                </button>
                                                                                            </div>
                                                                                        </form>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        </div>
                                                                        </div>
                                                                        <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\Mumara-WhatsApp\resources\views/pages/users/addUser.blade.php ENDPATH**/ ?>