<?php $__env->startSection('style'); ?>
<link href="/public/assets/css/toastr.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="/public/assets/js/jquery.js"type="text/javascript"></script>
<script src="/public/assets/js/jquery.validate.min.js"type="text/javascript"></script>
<script src="/public/assets/js/toastr.min.js"></script>
<script>
    $(document).ready(function () {
        $("#saveBtn").attr('disabled',false);
        $("#frmPackages").validate({
            rules: {
                role_name: "required",
            },
            messages: {
                role_name: "<?php echo e(trans('roles.add_role.validation_message.role_name')); ?>",
            },
            submitHandler: function (form) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('save.role')); ?>",
                    data: $("#frmPackages").serialize(),
                    cache: false,
                    dataType: 'json',
                    success: function (data) {
                        if (data.status == "success") {
                            var msgClass = 'success';
                        } else {
                            var msgClass = 'error';
                        }
                        Command: toastr[msgClass](data.message + '...');
                        if (data.status == "success") {
                            window.setTimeout(function () {
                              window.location.href = "<?php echo e(url('roles/view')); ?>";
                          }, 3000);  
                        }
                        
                    }
                });
            }
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="row g-5 g-xl-10">
    <div class="col-xl-12 col-md-6 mb-md-5">
        <?php echo $__env->make('partials.title_description', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    <div class="col-md-8 mb-md-5">
        <div class="card">
            <form id="frmPackages" name="frmPackages" class="form" method="post" action="" enctype="multipart/form-data">
                <input type="hidden" id="_token" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" value="<?php echo e($id); ?>" id="id" name="id">
                
                <div class="card-body border-top p-9">              
                    <div class="row mb-6">
                        <div class="col-lg-6">
                            <label class="col-form-label required fw-bold fs-6"><?php echo e(trans('roles.add_role.role_name')); ?></label>
                            <i class="fas fa-exclamation-circle ms-1 fs-7" data-bs-toggle="tooltip" title="" data-bs-original-title="<?php echo e(trans('roles.add_role.role_name_help')); ?>" aria-label="<?php echo e(trans('roles.add_role.role_name_help')); ?>"></i>
                            <div class="row">
                                <div class="fv-row mb-0 fv-plugins-icon-container">
                                    <input type="text" name="role_name" id="role_name" value="<?php echo e((isset($role['role_name']) ? $role['role_name']:"")); ?>" class="form-control bg-transparent" placeholder="<?php echo e(trans('roles.add_role.role_name')); ?>">
                                    <div class="fv-plugins-message-container invalid-feedback"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-stretch justify-content-between flex-lg-grow-1">
                    <a href="<?php echo e(route('view.roles')); ?>" data-kt-contacts-type="cancel" class="btn btn-light me-3">Cancel</a>
                    <button type="submit" class="btn btn-primary">
                      <span class="indicator-label">Save Changes</span>
                      <span class="indicator-progress">Please wait... 
                        <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                      </span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\Mumara-WhatsApp\resources\views/pages/roles/addRole.blade.php ENDPATH**/ ?>