<?php $__env->startSection('style'); ?>
<link href="/public/assets/css/datatables.bundle.css" rel="stylesheet" type="text/css" />
<link href="/public/assets/css/toastr.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="/public/assets/js/jquery.js"type="text/javascript"></script>
<script src="/public/assets/js/custom/datatables/datatables.bundle.js"type="text/javascript"></script>
<script src="/public/assets/js/toastr.min.js"></script>
<script>
    $(document).ready(function () {
        var objTable;
        objTable = $('#packageTable').dataTable({
            "aoColumnDefs": [{"bSortable": false, "aTargets": [0,2]}],
            "bProcessing": true,
            "bServerSide": true,
            "aaSorting": [[0, "DESC"]],
            "sPaginationType": "full_numbers",
            "sAjaxSource": "<?php echo e(route('get.users')); ?>",
            "drawCallback": function( settings ) {
                KTMenu.createInstances();
                KTMenu.updateDropdowns();
            },
            columnDefs: [{
            targets: 0,
            className: 'form-check form-check-custom form-check-solid align-items-center'
          },{
            targets: 1,
            className: 'min-w-125px'
          },{
            targets: 2,
            className: 'text-end w-100px'
          }],
            "aLengthMenu": [[20, 50, 100, 500], [20, 50, 100, 500]]
        });
        ///$('#packageTable').DataTable();
        $(document).on("click", ".icnDelete", function (event) {
            var id = this.id;
            var objRow = objTable.fnGetPosition($(this).closest('tr')[0]);
            var result = confirm("<?php echo e(trans('file.delete_record')); ?>");
            if (result) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('delete.role')); ?>",
                    data: {'role_id': id, '_token': token},
                    cache: false,
                    dataType:'json',
                    success: function (data) {
                        var msgClasss = '';
                        if (data.status == "success") {
                            msgClasss = 'success';
                            objTable.fnDeleteRow(objRow);
                        } else {
                            msgClasss = 'error';
                        }
                        Command: toastr[msgClasss] (data.message);
                    }

                });

            }
        });
    });
</script>
<script>
    $('.checkbox-all-index').click(function () {
        if ($(this).is(':checked')) {
            $('.checkbox-index').not(':disabled').prop('checked', true);
        } else {
            $('.checkbox-index').prop('checked', false);
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-5 g-xl-10">
    <div class="col-xl-12 col-md-6 mb-md-5">
        <?php echo $__env->make('partials.title_description', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-xl-12 col-md-6 mb-md-5">
        <div class="card">
            <div class="card-header py-6">
                <div class="card-toolbar">
                  <div class="d-flex justify-content-end" data-kt-user-table-toolbar="base">
                    <a class="btn btn-primary" href="<?php echo e(route('add.user')); ?>">
                      Add User</a>
                  </div>
                </div>
              </div>
            <div class="card-body py-4">
                <div class="table-responsive">
                    <table id="packageTable" class="table align-middle table-row-dashed fs-6 gy-5 dataTable no-footer" role="table">
                        <thead>
                            <tr class="text-start text-muted fw-bolder fs-7 text-uppercase gs-0">
                                <th  class="w-10px pe-2" tabindex="0">
                                    <div class="form-check form-check form-check-custom form-check-solid me-3">
                                        <input class="form-check-input checkbox-index  checkbox-all-index" type="checkbox" data-kt-check="false" data-kt-check-target="#kt_table_users ">
                                    </div>
                                </th>
                                <th tabindex="1"  class="min-w-125px"><?php echo e(trans('users.view_users.first_name')); ?></th>
                                <th tabindex="1"  class="min-w-125px"><?php echo e(trans('users.view_users.last_name')); ?></th>
                                <th tabindex="1"  class="min-w-125px"><?php echo e(trans('users.view_users.email')); ?></th>
                                <th tabindex="1"  class="min-w-125px"><?php echo e(trans('users.view_users.monile_no')); ?></th>
                                <th tabindex="1"  class="min-w-125px"><?php echo e(trans('users.view_users.role_name')); ?></th>
                                <th ><?php echo e(trans('users.view_users.action')); ?></th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-bold" role="rowgroup">
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wamp\www\Mumara-WhatsApp\resources\views/pages/users/viewUsers.blade.php ENDPATH**/ ?>