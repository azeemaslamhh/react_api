<?php

test('example', function () {
    expect(true)->toBeTrue();
});
